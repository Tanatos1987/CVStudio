@echo off
REM ==========================================================================
REM  CV Studio - diagnostic launcher
REM  Runs the app from source in this console window, so any error stays
REM  visible, then prints the log files. Use it when CVStudio.exe does not
REM  start. Needs install_and_run.bat to have run once (it creates .venv).
REM ==========================================================================
setlocal
cd /d "%~dp0"
title CV Studio diagnostics

if not exist ".venv\Scripts\python.exe" (
    echo   .venv was not found. Run install_and_run.bat first.
    pause
    exit /b 1
)

echo   Starting CV Studio from source. Close the app window to see the report.
echo.
".venv\Scripts\python.exe" -X faulthandler main.py
echo.
echo   Exit code: %errorlevel%
echo.
echo   ===== startup.log =====
type "%APPDATA%\CVStudio\logs\startup.log" 2>nul
echo.
echo   ===== error.log =====
type "%APPDATA%\CVStudio\logs\error.log" 2>nul
echo.
echo   ===== crash.log =====
type "%APPDATA%\CVStudio\logs\crash.log" 2>nul
echo.
echo   ===== qt.log (last lines) =====
powershell -NoProfile -Command "if (Test-Path \"$env:APPDATA\CVStudio\logs\qt.log\") { Get-Content \"$env:APPDATA\CVStudio\logs\qt.log\" -Tail 25 }"
echo.
echo   Take a screenshot of this window and send it.
pause
