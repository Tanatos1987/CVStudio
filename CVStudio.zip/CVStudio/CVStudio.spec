# -*- mode: python ; coding: utf-8 -*-
# PyInstaller recipe for a single-file, windowed CVStudio.exe
#   pyinstaller CVStudio.spec --noconfirm --clean
import os
from PyInstaller.utils.hooks import collect_data_files

ROOT = os.path.abspath(".")
icon = os.path.join(ROOT, "cvstudio", "assets", "icon.ico")

datas = [
    ("cvstudio/templates", "templates"),   # -> sys._MEIPASS/templates
    ("cvstudio/assets", "assets"),         # -> sys._MEIPASS/assets (fonts, icon)
]
datas += collect_data_files("docx")        # python-docx ships XML templates it may need

a = Analysis(
    ["main.py"],
    pathex=[ROOT],
    datas=datas,
    hiddenimports=[
        "deep_translator",
        "PyQt6.QtWebEngineCore",
        "PyQt6.QtWebEngineWidgets",
        "PyQt6.QtSvg",                     # checkbox tick is an SVG in the stylesheet
    ],
    excludes=[
        "tkinter", "matplotlib", "numpy", "pandas", "scipy", "IPython",
        "PyQt6.Qt3DCore", "PyQt6.QtBluetooth", "PyQt6.QtMultimedia", "PyQt6.QtQuick3D",
        "PyQt6.QtSensors", "PyQt6.QtSerialPort", "PyQt6.QtNfc",
    ],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="CVStudio",
    console=False,          # no black console window behind the app
    upx=False,              # UPX corrupts Qt WebEngine binaries and alarms antivirus tools
    icon=icon if os.path.exists(icon) else None,
    runtime_tmpdir=None,
)
