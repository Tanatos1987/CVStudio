"""
Build-time asset preparation. Run once before PyInstaller (the .bat does it).

1. Downloads the open-source fonts used by the templates and the UI from the
   official google/fonts repository (all SIL Open Font License, all with
   Cyrillic glyphs, so Bulgarian CVs render with the intended typography).
2. Draws the application icon with Qt and saves it as .ico and .png.

Safe to run repeatedly: files that already exist are skipped.
"""
from __future__ import annotations

import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FONTS = ROOT / "cvstudio" / "assets" / "fonts"
ICON_DIR = ROOT / "cvstudio" / "assets"

BASE = "https://raw.githubusercontent.com/google/fonts/main/ofl"
FONT_FILES = {
    "Manrope.ttf": "manrope/Manrope%5Bwght%5D.ttf",
    "Inter.ttf": "inter/Inter%5Bopsz,wght%5D.ttf",
    "Inter-Italic.ttf": "inter/Inter-Italic%5Bopsz,wght%5D.ttf",
    "PlayfairDisplay.ttf": "playfairdisplay/PlayfairDisplay%5Bwght%5D.ttf",
    "PlayfairDisplay-Italic.ttf": "playfairdisplay/PlayfairDisplay-Italic%5Bwght%5D.ttf",
    "Unbounded.ttf": "unbounded/Unbounded%5Bwght%5D.ttf",
    "CormorantGaramond.ttf": "cormorantgaramond/CormorantGaramond%5Bwght%5D.ttf",
    "CormorantGaramond-Italic.ttf": "cormorantgaramond/CormorantGaramond-Italic%5Bwght%5D.ttf",
}


def fetch_fonts() -> bool:
    FONTS.mkdir(parents=True, exist_ok=True)
    ok = True
    for name, remote in FONT_FILES.items():
        target = FONTS / name
        if target.exists() and target.stat().st_size > 10_000:
            print(f"  [skip] {name}")
            continue
        url = f"{BASE}/{remote}"
        try:
            print(f"  [get ] {name}")
            with urllib.request.urlopen(url, timeout=60) as r:
                target.write_bytes(r.read())
        except Exception as exc:
            ok = False
            print(f"  [fail] {name}: {exc}")
    return ok


TESSDATA = ROOT / "cvstudio" / "assets" / "tessdata"
TESS_BASE = "https://raw.githubusercontent.com/tesseract-ocr/tessdata_fast/main"


def fetch_tessdata() -> bool:
    """Bulgarian + English OCR models used by MuPDF's built-in Tesseract."""
    TESSDATA.mkdir(parents=True, exist_ok=True)
    ok = True
    for lang in ("bul", "eng"):
        target = TESSDATA / f"{lang}.traineddata"
        if target.exists() and target.stat().st_size > 500_000:
            print(f"  [skip] {target.name}")
            continue
        try:
            print(f"  [get ] {target.name}")
            with urllib.request.urlopen(f"{TESS_BASE}/{lang}.traineddata", timeout=120) as r:
                target.write_bytes(r.read())
        except Exception as exc:
            ok = False
            print(f"  [fail] {target.name}: {exc}")
    return ok


def make_icon() -> None:
    """A folded-corner sheet with a bold 'CV' monogram, drawn in Qt."""
    ico, png = ICON_DIR / "icon.ico", ICON_DIR / "icon.png"
    if ico.exists() and png.exists():
        print("  [skip] icon")
        return
    from PyQt6.QtCore import QPointF, QRectF, Qt
    from PyQt6.QtGui import QColor, QFont, QGuiApplication, QImage, QPainter, QPainterPath, QPolygonF

    app = QGuiApplication.instance() or QGuiApplication(sys.argv)  # noqa: F841
    size = 256
    img = QImage(size, size, QImage.Format.Format_ARGB32)
    img.fill(Qt.GlobalColor.transparent)
    p = QPainter(img)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)

    sheet = QPainterPath()
    sheet.addRoundedRect(QRectF(28, 14, 200, 228), 30, 30)
    p.fillPath(sheet, QColor("#232a3a"))
    fold = QPolygonF([QPointF(170, 14), QPointF(228, 72), QPointF(170, 72)])
    p.setBrush(QColor("#ffd34e"))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawPolygon(fold)

    font = QFont("Arial", 92, QFont.Weight.Black)
    p.setFont(font)
    p.setPen(QColor("#f4f1e8"))
    p.drawText(QRectF(28, 60, 200, 150), Qt.AlignmentFlag.AlignCenter, "CV")
    p.fillRect(QRectF(66, 196, 124, 10), QColor("#ffd34e"))
    p.end()

    img.save(str(png))
    img.scaled(256, 256).save(str(ico), "ICO")
    print("  [ok  ] icon")


if __name__ == "__main__":
    print("Fetching fonts...")
    fonts_ok = fetch_fonts()
    print("Fetching OCR language data...")
    if not fetch_tessdata():
        print("WARNING: OCR data missing, scanned CVs cannot be imported.")
    print("Drawing icon...")
    try:
        make_icon()
    except Exception as exc:  # the build continues without a custom icon
        print(f"  [fail] icon: {exc}")
    if not fonts_ok:
        print("WARNING: some fonts are missing. The app still works and falls back to system fonts.")
