"""
CV Studio entry point.

    python main.py            run from source
    CVStudio.exe              the PyInstaller build does the same thing

Order matters: QtWebEngine must be imported before QApplication exists,
and Chromium flags must be set before the first web view is created.

The .exe is a windowed app, so it has no console to print errors to.
Everything that could explain a failed start is written to
%APPDATA%\\CVStudio\\logs:

    startup.log   each start-up step, so the last line shows where it stopped
    crash.log     native crashes (Qt / Chromium), via faulthandler
    qt.log        warnings from Qt and QtWebEngine
    error.log     Python exceptions with full traceback
"""
from __future__ import annotations

import faulthandler
import os
import platform
import sys
import traceback
from datetime import datetime
from pathlib import Path

# --------------------------------------------------------------------------
# Logging that works before Qt exists
# --------------------------------------------------------------------------
from cvstudio.paths import user_data_dir  # pure Python, safe to import first

LOG_DIR = user_data_dir() / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
_crash_file = open(LOG_DIR / "crash.log", "w", encoding="utf-8")  # kept open on purpose
faulthandler.enable(_crash_file, all_threads=True)
(LOG_DIR / "startup.log").write_text("", encoding="utf-8")


def log(step: str) -> None:
    with open(LOG_DIR / "startup.log", "a", encoding="utf-8") as fh:
        fh.write(f"{datetime.now():%H:%M:%S}  {step}\n")


def fatal(message: str, details: str = "") -> None:
    """Show an error even when no Qt window can be created."""
    with open(LOG_DIR / "error.log", "a", encoding="utf-8") as fh:
        fh.write(f"\n==== {datetime.now():%Y-%m-%d %H:%M:%S} ====\n{message}\n{details}\n")
    text = (f"{message}\n\nLog files are in:\n{LOG_DIR}\n\n"
            "Send startup.log and error.log if you need help.")
    try:
        from PyQt6.QtWidgets import QApplication, QMessageBox
        if QApplication.instance():
            QMessageBox.critical(None, "CV Studio", text)
            return
    except Exception:
        pass
    if sys.platform.startswith("win"):
        import ctypes
        ctypes.windll.user32.MessageBoxW(None, text, "CV Studio", 0x10)
    else:
        print(text, file=sys.stderr)


def _excepthook(exc_type, exc, tb):
    fatal(f"Unexpected error: {exc}", "".join(traceback.format_exception(exc_type, exc, tb)))
    sys.__excepthook__(exc_type, exc, tb)


sys.excepthook = _excepthook
log(f"CV Studio starting. Python {platform.python_version()} {platform.architecture()[0]}, "
    f"{platform.platform()}, frozen={getattr(sys, 'frozen', False)}")
log(f"executable: {sys.executable}")

# --------------------------------------------------------------------------
# Environment for Qt / Chromium (must be set before Qt is imported)
# --------------------------------------------------------------------------
os.environ.setdefault("QT_ENABLE_HIGHDPI_SCALING", "1")
# The preview is a static document, so the GPU gives no benefit here, while
# some Windows graphics drivers make Chromium crash or show a blank page at
# start. Software rendering avoids that. Set CVSTUDIO_GPU=1 to use the GPU.
if os.environ.get("CVSTUDIO_GPU") != "1":
    os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS",
                          "--disable-gpu --disable-gpu-compositing --log-level=3")
else:
    os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--log-level=3")
log(f"chromium flags: {os.environ.get('QTWEBENGINE_CHROMIUM_FLAGS')}")

try:
    from PyQt6 import QtWebEngineWidgets  # noqa: F401  (must precede QApplication)
    from PyQt6.QtCore import QLibraryInfo, QTranslator, QtMsgType, Qt, qInstallMessageHandler
    from PyQt6.QtWidgets import QApplication
except Exception as exc:  # broken or incomplete install
    fatal(f"Qt could not be loaded: {exc}", traceback.format_exc())
    sys.exit(1)
log("Qt imported")


def _qt_messages(kind, context, message):
    if kind == QtMsgType.QtDebugMsg:
        return
    with open(LOG_DIR / "qt.log", "a", encoding="utf-8") as fh:
        fh.write(f"{datetime.now():%H:%M:%S} [{kind.name}] {message}\n")


def main() -> int:
    qInstallMessageHandler(_qt_messages)
    QApplication.setHighDpiScaleFactorRoundingPolicy(Qt.HighDpiScaleFactorRoundingPolicy.PassThrough)
    app = QApplication(sys.argv)
    app.setApplicationName("CV Studio")
    app.setOrganizationName("CVStudio")
    log("QApplication created")

    from cvstudio.database import Database
    from cvstudio.paths import database_path, resource_root
    from cvstudio.ui import i18n, theme
    from cvstudio.ui.main_window import MainWindow

    log(f"resources: {resource_root()}  templates present: {(resource_root() / 'templates').exists()}")
    theme.apply(app)
    log("theme applied")
    db = Database(database_path())
    log(f"database opened: {database_path()}")

    # Interface language: Bulgarian unless the user picked English before.
    qt_translator = QTranslator(app)

    def apply_language(code: str) -> None:
        i18n.set_language(code)
        app.removeTranslator(qt_translator)
        # Qt's own texts (Yes / No / Cancel buttons in message boxes)
        if code == "bg" and qt_translator.load("qtbase_bg",
                                               QLibraryInfo.path(QLibraryInfo.LibraryPath.TranslationsPath)):
            app.installTranslator(qt_translator)

    apply_language(db.get_setting("ui_lang", "bg"))

    windows: list[MainWindow] = []

    def open_window(geometry=None, maximized: bool = False) -> None:
        w = MainWindow(db)
        w.language_switch_requested.connect(lambda code, old=w: switch_language(old, code))
        windows.append(w)
        if geometry is None:
            w.show_sized()
        else:
            w.restoreGeometry(geometry)
            w.showMaximized() if maximized else w.show()

    def switch_language(old: MainWindow, code: str) -> None:
        """Rebuild the window in the other language. Data is saved first."""
        old.save_now()
        db.set_setting("ui_lang", code)
        apply_language(code)
        geometry, maximized = old.saveGeometry(), old.isMaximized()
        old._restarting = True
        open_window(geometry, maximized)
        old.close()
        windows.remove(old)
        old.deleteLater()
        log(f"interface language switched to {code}")

    open_window()
    log("main window shown, entering event loop")
    code = app.exec()
    log(f"event loop ended with code {code}")
    db.close()
    return code


if __name__ == "__main__":
    try:
        sys.exit(main())
    except SystemExit:
        raise
    except Exception as exc:
        fatal(f"CV Studio could not start: {exc}", traceback.format_exc())
        sys.exit(1)
