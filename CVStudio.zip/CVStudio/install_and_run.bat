@echo off
REM ==========================================================================
REM  CV Studio - one-click setup, build and launch for Windows
REM
REM  install_and_run.bat          set up, build CVStudio.exe (first time), run it
REM  install_and_run.bat rebuild  force a fresh .exe build
REM  install_and_run.bat dev      run straight from the source code, no build
REM ==========================================================================
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title CV Studio setup

set "MODE=%~1"
set "VENV=.venv"
set "VPY=%VENV%\Scripts\python.exe"
set "EXE=dist\CVStudio.exe"

echo.
echo   CV Studio
echo   ---------------------------------------------
echo.

REM --- Fast path: launch the existing exe if it matches the source version ---
REM A rebuild happens automatically when cvstudio\__init__.py carries a newer
REM __version__ than the one recorded next to the exe at build time.
if /I "%MODE%"=="rebuild" goto :full_setup
if /I "%MODE%"=="dev" goto :full_setup
if not exist "%EXE%" goto :full_setup
findstr /b "__version__" cvstudio\__init__.py > "%TEMP%\cvstudio_ver.txt" 2>nul
fc /b "%TEMP%\cvstudio_ver.txt" "dist\build_version.txt" >nul 2>&1
if errorlevel 1 (
    echo   The source code is newer than CVStudio.exe, building it again...
    echo.
    goto :full_setup
)
echo   CVStudio.exe is up to date. Starting it...
start "" "%EXE%"
call :launch_note
exit /b 0

:full_setup
REM --- 1. Find a usable Python ----------------------------------------------
REM Any 64-bit Python 3.10 or newer works (all dependencies ship wheels for
REM 3.14). Tried in order: the py launcher with preferred versions, the
REM launcher's default, python / python3 on PATH, the standard install folders.
echo [1/5] Looking for Python...
set "PY="
set "PYVER="
for %%C in ("py -3.13" "py -3.12" "py -3.14" "py -3.11" "py -3.10" "py" "python" "python3") do (
    if not defined PY call :try_python %%~C
)
if not defined PY (
    for /d %%D in ("%LocalAppData%\Programs\Python\Python3*" "%ProgramFiles%\Python3*" "C:\Python3*") do (
        if not defined PY if exist "%%~D\python.exe" call :try_python "%%~D\python.exe"
    )
)
if defined PY goto :python_ok

echo.
echo   No usable Python was found. CV Studio needs 64-bit Python 3.10 or newer.
echo.
echo   What this computer reports (send this screen if Python IS installed):
echo   --- py --list ---
py --list 2>&1
echo   --- where python ---
where python 2>&1
echo.
echo   If nothing is installed: get "Windows installer (64-bit)" of Python 3.13
echo   from the page that opens now, tick "Add python.exe to PATH", then run
echo   this file again.
start "" "https://www.python.org/downloads/windows/"
pause
exit /b 1

:python_ok
echo       using %PY%  ^(Python %PYVER%^)

REM --- 2. Virtual environment -------------------------------------------------
echo [2/5] Preparing the virtual environment...
if exist "%VPY%" goto :venv_ok
%PY% -m venv "%VENV%"
if errorlevel 1 goto :fail
:venv_ok

REM --- 3. Dependencies --------------------------------------------------------
echo [3/5] Installing dependencies ^(first run downloads about 250 MB^)...
"%VPY%" -m pip install --upgrade pip --disable-pip-version-check -q
if errorlevel 1 goto :fail
"%VPY%" -m pip install -r requirements.txt --disable-pip-version-check
if errorlevel 1 goto :fail

REM --- 4. Fonts and icon ------------------------------------------------------
echo [4/5] Downloading fonts and drawing the app icon...
"%VPY%" build_tools\fetch_assets.py
if errorlevel 1 echo       Assets step reported a problem. Continuing with fallbacks.

if /I "%MODE%"=="dev" (
    echo.
    echo   Starting from source...
    "%VPY%" main.py
    exit /b !errorlevel!
)

REM --- 5. Build the single .exe -----------------------------------------------
echo [5/5] Building CVStudio.exe ^(takes 2-5 minutes^)...
tasklist /fi "imagename eq CVStudio.exe" 2>nul | find /i "CVStudio.exe" >nul
if not errorlevel 1 (
    echo       CV Studio is running. Close it, then press a key to continue.
    pause >nul
)
if exist build rmdir /s /q build
if exist "%EXE%" del /q "%EXE%"
if exist "%EXE%" (
    echo       dist\CVStudio.exe is locked. Close CV Studio and run this file again.
    goto :fail
)
"%VPY%" -m PyInstaller CVStudio.spec --noconfirm --clean --log-level WARN
if errorlevel 1 goto :fail
if not exist "%EXE%" goto :fail

REM Record which source version this exe was built from (see fast path).
findstr /b "__version__" cvstudio\__init__.py > "dist\build_version.txt"
REM Put a copy next to this script so it is easy to find.
copy /y "%EXE%" "CVStudio.exe" >nul

echo.
echo   Done. CVStudio.exe is ready in this folder ^(and in dist\^).
echo   You can copy it anywhere, Python is no longer needed to run it.
echo   Your CVs are stored in %%APPDATA%%\CVStudio
echo.
start "" "CVStudio.exe"
call :launch_note
exit /b 0

:fail
echo.
echo   Setup stopped because the step above failed.
echo   Check your internet connection, then run this file again.
echo   If it keeps failing, delete the .venv folder and retry.
pause
exit /b 1


REM ==========================================================================
REM  :try_python <command>
REM  Runs the candidate once and asks it about itself. Sets PY and PYVER only
REM  if it is Python 3.10+ and 64-bit. Silent for commands that do not exist
REM  (including the Microsoft Store "python" placeholder).
REM ==========================================================================
:try_python
set "CAND=%*"
set "CVS_TMP=%TEMP%\cvstudio_pycheck.txt"
REM The new Python install manager may offer to download a missing version
REM and wait for an answer. Input from nul and this switch stop that.
set "PYTHON_MANAGER_AUTOMATIC_INSTALL=false"
if exist "%CVS_TMP%" del /q "%CVS_TMP%" >nul 2>&1
%CAND% -c "import sys,struct; v=sys.version.split()[0]; ok=sys.version_info[:2]>=(3,10); b=struct.calcsize('P')*8; print('OK' if ok and b==64 else ('OLD' if not ok else 'BIT32'), v, b)" < nul > "%CVS_TMP%" 2>nul
set "R_STATE="
set "R_VER="
if exist "%CVS_TMP%" for /f "usebackq tokens=1,2" %%a in ("%CVS_TMP%") do (
    set "R_STATE=%%a"
    set "R_VER=%%b"
)
if exist "%CVS_TMP%" del /q "%CVS_TMP%" >nul 2>&1
if not defined R_STATE exit /b 0
if "%R_STATE%"=="OK" (
    set "PY=!CAND!"
    set "PYVER=!R_VER!"
    exit /b 0
)
if "%R_STATE%"=="OLD" echo       skipped %CAND%: Python %R_VER% is too old, 3.10+ needed
if "%R_STATE%"=="BIT32" echo       skipped %CAND%: Python %R_VER% is 32-bit, 64-bit needed
exit /b 0


REM ==========================================================================
REM  :launch_note - what to expect after start, and what to do if nothing opens
REM ==========================================================================
:launch_note
echo.
echo   The first start after a build takes 10-20 seconds while the exe unpacks.
echo   If no window appears, or it closes by itself, run run_debug.bat and
echo   send a screenshot of its window. Logs: %%APPDATA%%\CVStudio\logs
echo.
echo   This window closes by itself in 30 seconds.
timeout /t 30 >nul
exit /b 0
