"""
SQLite storage for CV profiles.

One row per CV version. The CV content is a JSON document (see models.py);
photos are BLOB columns so a profile is a single self-contained record that
can be duplicated with one INSERT ... SELECT.

``PRAGMA user_version`` tracks the schema version. Add a new ``_migrate_to_N``
step when the schema changes; existing user databases upgrade on launch.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from pathlib import Path

from .models import Profile, empty_data, normalise

SCHEMA_VERSION = 1


class Database:
    def __init__(self, path: Path):
        self.path = path
        self.conn = sqlite3.connect(str(path))
        self.conn.row_factory = sqlite3.Row
        # WAL keeps the file consistent if the app is killed mid-write.
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._migrate()

    # ------------------------------------------------------------------
    # Schema
    # ------------------------------------------------------------------
    def _migrate(self) -> None:
        version = self.conn.execute("PRAGMA user_version").fetchone()[0]
        if version < 1:
            self._migrate_to_1()
        self.conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")
        self.conn.commit()

    def _migrate_to_1(self) -> None:
        self.conn.executescript(
            """
            CREATE TABLE IF NOT EXISTS profiles (
                id             INTEGER PRIMARY KEY AUTOINCREMENT,
                name           TEXT    NOT NULL,
                template       TEXT    NOT NULL DEFAULT 'modern_tech',
                accent         TEXT    NOT NULL DEFAULT '',
                language       TEXT    NOT NULL DEFAULT 'en',
                data           TEXT    NOT NULL,
                photo          BLOB,
                photo_original BLOB,
                created_at     TEXT    NOT NULL,
                updated_at     TEXT    NOT NULL
            );
            CREATE TABLE IF NOT EXISTS settings (
                key   TEXT PRIMARY KEY,
                value TEXT
            );
            """
        )

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _now() -> str:
        return datetime.now().isoformat(timespec="seconds")

    @staticmethod
    def _row_to_profile(row: sqlite3.Row) -> Profile:
        return Profile(
            id=row["id"],
            name=row["name"],
            template=row["template"],
            accent=row["accent"],
            language=row["language"],
            data=normalise(json.loads(row["data"])),
            photo=row["photo"],
            photo_original=row["photo_original"],
            updated_at=row["updated_at"],
        )

    # ------------------------------------------------------------------
    # Profiles
    # ------------------------------------------------------------------
    def list_profiles(self) -> list[tuple[int, str, str]]:
        rows = self.conn.execute(
            "SELECT id, name, updated_at FROM profiles ORDER BY updated_at DESC"
        ).fetchall()
        return [(r["id"], r["name"], r["updated_at"]) for r in rows]

    def load(self, profile_id: int) -> Profile | None:
        row = self.conn.execute("SELECT * FROM profiles WHERE id=?", (profile_id,)).fetchone()
        return self._row_to_profile(row) if row else None

    def create(self, name: str, template: str = "modern_tech", language: str = "en") -> Profile:
        now = self._now()
        cur = self.conn.execute(
            "INSERT INTO profiles(name, template, language, data, created_at, updated_at) "
            "VALUES (?,?,?,?,?,?)",
            (name, template, language, json.dumps(empty_data(), ensure_ascii=False), now, now),
        )
        self.conn.commit()
        return self.load(cur.lastrowid)  # type: ignore[return-value]

    def save(self, p: Profile) -> str:
        """Insert or update. Returns the new ``updated_at`` stamp."""
        now = self._now()
        payload = json.dumps(p.data, ensure_ascii=False)
        if p.id is None:
            cur = self.conn.execute(
                "INSERT INTO profiles(name, template, accent, language, data, photo, "
                "photo_original, created_at, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                (p.name, p.template, p.accent, p.language, payload, p.photo,
                 p.photo_original, now, now),
            )
            p.id = cur.lastrowid
        else:
            self.conn.execute(
                "UPDATE profiles SET name=?, template=?, accent=?, language=?, data=?, "
                "photo=?, photo_original=?, updated_at=? WHERE id=?",
                (p.name, p.template, p.accent, p.language, payload, p.photo,
                 p.photo_original, now, p.id),
            )
        self.conn.commit()
        p.updated_at = now
        return now

    def duplicate(self, profile_id: int, new_name: str) -> Profile:
        now = self._now()
        cur = self.conn.execute(
            "INSERT INTO profiles(name, template, accent, language, data, photo, "
            "photo_original, created_at, updated_at) "
            "SELECT ?, template, accent, language, data, photo, photo_original, ?, ? "
            "FROM profiles WHERE id=?",
            (new_name, now, now, profile_id),
        )
        self.conn.commit()
        return self.load(cur.lastrowid)  # type: ignore[return-value]

    def delete(self, profile_id: int) -> None:
        self.conn.execute("DELETE FROM profiles WHERE id=?", (profile_id,))
        self.conn.commit()

    # ------------------------------------------------------------------
    # Settings (last opened profile, splitter sizes, ...)
    # ------------------------------------------------------------------
    def get_setting(self, key: str, default: str = "") -> str:
        row = self.conn.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

    def set_setting(self, key: str, value: str) -> None:
        self.conn.execute(
            "INSERT INTO settings(key, value) VALUES(?,?) "
            "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
            (key, value),
        )
        self.conn.commit()

    def close(self) -> None:
        self.conn.close()
