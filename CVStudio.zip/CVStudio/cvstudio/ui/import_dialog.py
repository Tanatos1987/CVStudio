"""
Import an old CV.

Left: the full extracted text, selectable, so anything can be copied into
any field with Ctrl+C / Ctrl+V. Right: what the parser recognised, each
item with a checkbox. "Add checked items" merges them into the open CV
(lists are appended, never replaced). The dialog is non-modal and stays
open, so the user can keep copying from it while editing.
"""
from __future__ import annotations

import re
from typing import Any

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QImage, QPixmap
from PyQt6.QtWidgets import (QCheckBox, QDialog, QHBoxLayout, QLabel, QLineEdit, QPlainTextEdit,
                             QPushButton, QScrollArea, QSplitter, QVBoxLayout, QWidget)

from ..cv_parser import ParsedCV, guess_entries, guess_languages, guess_list
from .i18n import lang as ui_lang
from .i18n import t


def _split_language(text: str) -> dict[str, str]:
    parts = re.split(r"\s*[-:(\u2013]\s*", text, maxsplit=1)
    return {"name": parts[0].strip(), "level": parts[1].strip(" )") if len(parts) > 1 else ""}


class ImportDialog(QDialog):
    apply_requested = pyqtSignal(dict)

    LABELS = {"full_name": "Name", "email": "Email", "phone": "Phone", "website": "Website",
              "linkedin": "LinkedIn", "github": "GitHub"}

    def __init__(self, parsed: ParsedCV, parent=None):
        super().__init__(parent)
        self.parsed = parsed
        self.setWindowTitle(t("Import: {file}", file=parsed.source.name))
        self.setModal(False)
        self.resize(1080, 720)

        root = QVBoxLayout(self)
        root.setContentsMargins(18, 18, 18, 18)
        root.setSpacing(12)
        hint = QLabel(t("Select any text on the left and press Ctrl+C to paste it into a field. "
                        "Tick what was recognised on the right and add it to your CV."))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        root.addWidget(hint)
        if parsed.ocr:
            note = QLabel(t("This file is a scan or an image, so the text was recognised with OCR. "
                            "Check names, numbers and dates for recognition errors."))
            note.setWordWrap(True)
            note.setStyleSheet("background:#3a3320; color:#ffd34e; padding:8px 10px; border-radius:8px;")
            root.addWidget(note)

        split = QSplitter(Qt.Orientation.Horizontal)
        raw = QPlainTextEdit(parsed.text)
        raw.setReadOnly(True)
        raw.setLineWrapMode(QPlainTextEdit.LineWrapMode.WidgetWidth)
        split.addWidget(raw)

        right = QScrollArea()
        right.setWidgetResizable(True)
        right.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        panel = QWidget()
        self.form = QVBoxLayout(panel)
        self.form.setSpacing(10)
        right.setWidget(panel)
        split.addWidget(right)
        split.setSizes([560, 480])
        root.addWidget(split, 1)

        self.personal_rows: dict[str, tuple[QCheckBox, QLineEdit]] = {}
        self.items: dict[str, tuple[QCheckBox, Any]] = {}
        self._build()

        buttons = QHBoxLayout()
        buttons.addStretch()
        close = QPushButton(t("Close"))
        close.clicked.connect(self.close)
        apply = QPushButton(t("Add checked items to CV"))
        apply.setObjectName("Primary")
        apply.clicked.connect(self._apply)
        buttons.addWidget(close)
        buttons.addWidget(apply)
        root.addLayout(buttons)

    # ------------------------------------------------------------------
    def _heading(self, text: str) -> None:
        l = QLabel(t(text))
        l.setObjectName("CardTitle")
        self.form.addSpacing(6)
        self.form.addWidget(l)

    def _check(self, key: str, label: str, payload: Any) -> None:
        short = label if len(label) <= 62 else label[:60].rstrip() + "..."
        box = QCheckBox(short)
        box.setToolTip(label)
        box.setChecked(True)
        self.items[key] = (box, payload)
        self.form.addWidget(box)

    def _build(self) -> None:
        p = self.parsed
        if p.photo:
            self._heading("Photo found in the file")
            img = QImage.fromData(p.photo)
            if not img.isNull():
                thumb = QLabel()
                thumb.setPixmap(QPixmap.fromImage(img).scaled(
                    96, 96, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
                self.form.addWidget(thumb)
                self._check("photo", t("Use as profile photo (you can crop it next)"), p.photo)

        if p.personal:
            self._heading("Contact details")
            for key, value in p.personal.items():
                row = QHBoxLayout()
                box = QCheckBox(t(self.LABELS.get(key, key)))
                box.setChecked(True)
                box.setMinimumWidth(90)
                edit = QLineEdit(value)
                row.addWidget(box)
                row.addWidget(edit, 1)
                self.form.addLayout(row)
                self.personal_rows[key] = (box, edit)

        s = p.sections
        if s.get("summary"):
            self._heading("Profile")
            self._check("summary", s["summary"].replace("\n", " "), s["summary"])
        for key, title, a, b in (("experience", "Experience", "title", "company"),
                                 ("education", "Education", "degree", "institution")):
            if s.get(key):
                entries = guess_entries(s[key])
                if entries:
                    self._heading(title)
                    mapped = [{a: e["a"], b: e["b"], "start": e["start"], "end": e["end"],
                               "location": "", "description": e["description"]} for e in entries]
                    for i, m in enumerate(mapped):
                        label = " / ".join(x for x in (m[a], m[b], f"{m['start']} - {m['end']}"
                                                        if m["start"] else "") if x)
                        self._check(f"{key}:{i}", label or t("(untitled block)"), m)
        if s.get("skills"):
            skills = guess_list(s["skills"])
            if skills:
                self._heading("Skills")
                self._check("skills", ", ".join(skills[:12]) + (" ..." if len(skills) > 12 else ""),
                            [{"name": x, "level": 3} for x in skills])
        if s.get("languages"):
            langs = guess_languages(s["languages"])
            if langs:
                self._heading("Languages")
                self._check("languages", ", ".join(f"{l['name']} {l['level']}".strip() for l in langs), langs)
        if s.get("certifications"):
            certs = guess_list(s["certifications"])
            if certs:
                self._heading("Certifications")
                self._check("certifications", ", ".join(certs[:6]),
                            [{"name": c, "issuer": "", "year": ""} for c in certs])

        if not (p.personal or p.sections or p.photo):
            none = QLabel(t("No sections were recognised automatically. Copy what you need from the text on the left."))
            none.setWordWrap(True)
            none.setObjectName("Muted")
            self.form.addWidget(none)
        self.form.addStretch()

    def _apply(self) -> None:
        out: dict[str, Any] = {"personal": {}, "experience": [], "education": []}
        for key, (box, edit) in self.personal_rows.items():
            if box.isChecked() and edit.text().strip():
                out["personal"][key] = edit.text().strip()
        for key, (box, payload) in self.items.items():
            if not box.isChecked():
                continue
            if key.startswith(("experience:", "education:")):
                out[key.split(":")[0]].append(payload)
            else:
                out[key] = payload
        self.apply_requested.emit(out)
