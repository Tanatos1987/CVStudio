"""
The editor pages shown in the centre column.

Every page offers ``get()`` / ``set()`` for its slice of the profile data
and a ``changed`` signal. The main window owns the Profile object and does
the saving, so pages stay dumb and easy to test.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from PyQt6.QtCore import QSize, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QIcon, QPainter, QPixmap
from PyQt6.QtWidgets import (QColorDialog, QComboBox, QFrame, QGridLayout, QHBoxLayout, QLabel,
                             QPushButton, QScrollArea, QToolButton, QVBoxLayout, QWidget)

from ..models import LETTER_FIELDS, PERSONAL_FIELDS, SectionSpec
from ..renderer import TemplateInfo
from . import theme
from .photo import PhotoFrame
from .i18n import lang as ui_lang
from .i18n import t
from .widgets import Field, ListSection, page_header


class FormPage(QScrollArea):
    changed = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        inner = QWidget()
        outer = QHBoxLayout(inner)
        outer.setContentsMargins(30, 28, 30, 40)
        column = QWidget()
        column.setMaximumWidth(760)
        self.body = QVBoxLayout(column)
        self.body.setContentsMargins(0, 0, 0, 0)
        self.body.setSpacing(16)
        outer.addWidget(column)
        self.setWidget(inner)

    def finish(self) -> None:
        self.body.addStretch(1)


# --------------------------------------------------------------------------
class PersonalPage(FormPage):
    photo_changed = pyqtSignal(object, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.body.addWidget(page_header(
            t("Personal details"),
            t("The basics recruiters scan first. Empty fields are left out of the CV.")))
        self.photo = PhotoFrame()
        self.photo.photo_changed.connect(self.photo_changed)
        self.body.addWidget(self.photo)

        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(12)
        self.fields: dict[str, Field] = {}
        i = 0
        for spec in PERSONAL_FIELDS:
            f = Field(spec)
            f.changed.connect(self.changed)
            self.fields[spec.key] = f
            if spec.kind == "text":
                continue
            grid.addWidget(f, i // 2, i % 2)
            i += 1
        self.body.addLayout(grid)
        summary = self.fields["summary"]
        summary.editor.setPlaceholderText(
            t("Two or three sentences: what you do, for whom, and one result with a number in it."))
        self.body.addWidget(summary)
        self.finish()

    def get(self) -> dict[str, Any]:
        return {k: f.value() for k, f in self.fields.items()}

    def set(self, data: dict[str, Any]) -> None:
        for k, f in self.fields.items():
            f.set_value(data.get(k, ""))


# --------------------------------------------------------------------------
class SectionPage(FormPage):
    HINTS = {
        "experience": "Newest first. Start each achievement with a verb and keep one per line.",
        "education": "Degrees, schools and notable training.",
        "skills": "The level drives the meters, dots or highlighted pills, depending on the design.",
        "languages": "Use CEFR levels (A1-C2) or words like Native.",
        "certifications": "Licences, certificates and courses worth showing.",
    }

    def __init__(self, spec: SectionSpec, parent=None):
        super().__init__(parent)
        self.spec = spec
        title = spec.title_bg if ui_lang() == "bg" else spec.title_en
        self.body.addWidget(page_header(title, t(self.HINTS.get(spec.key, ""))))
        self.section = ListSection(spec)
        self.section.changed.connect(self.changed)
        self.body.addWidget(self.section)
        self.finish()

    def get(self) -> list[dict[str, Any]]:
        return self.section.get()

    def set(self, items: list[dict[str, Any]]) -> None:
        self.section.set(items)


# --------------------------------------------------------------------------
class CoverLetterPage(FormPage):
    generate_requested = pyqtSignal()
    today_requested = pyqtSignal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.body.addWidget(page_header(
            t("Cover letter"),
            t("Uses the same design, colours and header as your CV. Switch the preview to "
              "Letter to see it.")))
        grid = QGridLayout()
        grid.setHorizontalSpacing(14)
        grid.setVerticalSpacing(12)
        self.fields: dict[str, Field] = {}
        i = 0
        for spec in LETTER_FIELDS:
            f = Field(spec)
            f.changed.connect(self.changed)
            self.fields[spec.key] = f
            if spec.kind != "text":
                grid.addWidget(f, i // 2, i % 2)
                i += 1
        self.body.addLayout(grid)

        actions = QHBoxLayout()
        gen = QPushButton(t("Write a draft from my CV"))
        gen.setObjectName("Primary")
        gen.setToolTip(t("Builds a first draft from your latest job, strongest results and top skills"))
        gen.clicked.connect(self.generate_requested)
        today = QPushButton(t("Use today's date"))
        today.clicked.connect(self.today_requested)
        actions.addWidget(gen)
        actions.addWidget(today)
        actions.addStretch()
        self.body.addLayout(actions)

        body = self.fields["body"]
        body.editor._min_lines = 14
        body.editor._fit()
        self.body.addWidget(body)
        self.finish()

    def get(self) -> dict[str, Any]:
        return {k: f.value() for k, f in self.fields.items()}

    def set(self, data: dict[str, Any]) -> None:
        for k, f in self.fields.items():
            f.set_value(data.get(k, ""))


# --------------------------------------------------------------------------
class TemplateCard(QFrame):
    clicked = pyqtSignal(str)

    THUMB = QSize(206, 291)

    def __init__(self, info: TemplateInfo, parent=None):
        super().__init__(parent)
        self.info = info
        self.setObjectName("TemplateCard")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 12, 12, 14)
        lay.setSpacing(6)
        self.thumb = QLabel()
        self.thumb.setFixedSize(self.THUMB)
        self.thumb.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.thumb.setStyleSheet(f"background:{theme.FIELD}; border-radius:8px; color:{theme.FAINT};")
        self.thumb.setText(t("Rendering preview..."))
        lay.addWidget(self.thumb, 0, Qt.AlignmentFlag.AlignHCenter)
        bg = ui_lang() == "bg"
        name = QLabel(info.name_bg if bg and info.name_bg else info.name)
        name.setObjectName("TplName")
        tag = QLabel(info.tagline_bg if bg and info.tagline_bg else info.tagline)
        tag.setObjectName("TplTag")
        tag.setWordWrap(True)
        lay.addWidget(name)
        lay.addWidget(tag)
        self.set_selected(False)

    def set_thumbnail(self, png: Path) -> None:
        pm = QPixmap(str(png))
        if pm.isNull():
            return
        ratio = self.devicePixelRatioF()
        pm = pm.scaled(self.THUMB * ratio, Qt.AspectRatioMode.KeepAspectRatio,
                       Qt.TransformationMode.SmoothTransformation)
        pm.setDevicePixelRatio(ratio)
        self.thumb.setPixmap(pm)
        self.thumb.setStyleSheet("background:white; border-radius:8px;")

    def set_selected(self, on: bool) -> None:
        self.setProperty("selected", "true" if on else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def mouseReleaseEvent(self, e):
        self.clicked.emit(self.info.id)

    def keyPressEvent(self, e):
        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Space):
            self.clicked.emit(self.info.id)
        else:
            super().keyPressEvent(e)


def _swatch_icon(colour: str, ring: bool) -> QIcon:
    pm = QPixmap(56, 56)
    pm.fill(Qt.GlobalColor.transparent)
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing)
    if ring:
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(theme.TEXT))
        p.drawEllipse(2, 2, 52, 52)
        p.setBrush(QColor(theme.BASE))
        p.drawEllipse(6, 6, 44, 44)
    p.setPen(Qt.PenStyle.NoPen)
    p.setBrush(QColor(colour))
    p.drawEllipse(10, 10, 36, 36)
    p.end()
    pm.setDevicePixelRatio(2)
    return QIcon(pm)


class TemplatesPage(FormPage):
    template_chosen = pyqtSignal(str)
    accent_chosen = pyqtSignal(str)     # "" = template default
    language_chosen = pyqtSignal(str)   # labels language: "en" / "bg"

    def __init__(self, templates: list[TemplateInfo], parent=None):
        super().__init__(parent)
        self.templates = {tpl.id: tpl for tpl in templates}
        self.body.addWidget(page_header(
            t("Design"),
            t("Pick a layout, then a colour. The preview and the exported PDF use the same rendering "
              "engine, so what you see is what prints.")))
        grid = QGridLayout()
        grid.setSpacing(16)
        self.cards: dict[str, TemplateCard] = {}
        for i, info in enumerate(templates):
            card = TemplateCard(info)
            card.clicked.connect(self.template_chosen)
            self.cards[info.id] = card
            grid.addWidget(card, i // 2, i % 2)
        self.body.addLayout(grid)

        colour_title = QLabel(t("Accent colour"))
        colour_title.setObjectName("CardTitle")
        self.body.addWidget(colour_title)
        self.swatch_row = QHBoxLayout()
        self.swatch_row.setSpacing(4)
        self.body.addLayout(self.swatch_row)

        lang_row = QHBoxLayout()
        lang_label = QLabel(t("Section headings language"))
        lang_label.setObjectName("CardTitle")
        self.lang = QComboBox()
        self.lang.addItem("English", "en")
        self.lang.addItem("Български", "bg")
        self.lang.currentIndexChanged.connect(lambda _: self.language_chosen.emit(self.lang.currentData()))
        lang_row.addWidget(lang_label)
        lang_row.addStretch()
        lang_row.addWidget(self.lang)
        self.body.addLayout(lang_row)
        hint = QLabel(t("Headings switch automatically when you translate the CV. Change them here if you write the "
                        "content in one language by hand."))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        self.body.addWidget(hint)
        self.finish()
        self._current_template = ""
        self._current_accent = ""

    def set_thumbnail(self, template_id: str, png: Path) -> None:
        if template_id in self.cards:
            self.cards[template_id].set_thumbnail(png)

    def set_state(self, template_id: str, accent: str, language: str) -> None:
        self._current_template, self._current_accent = template_id, accent
        for tid, card in self.cards.items():
            card.set_selected(tid == template_id)
        self._build_swatches()
        self.lang.blockSignals(True)
        self.lang.setCurrentIndex(1 if language == "bg" else 0)
        self.lang.blockSignals(False)

    def _build_swatches(self) -> None:
        while self.swatch_row.count():
            item = self.swatch_row.takeAt(0)
            if item.widget():
                item.widget().deleteLater()
        info = self.templates.get(self._current_template)
        if not info:
            return
        active = (self._current_accent or info.default_accent).lower()
        for colour in info.swatches:
            b = QToolButton()
            b.setIcon(_swatch_icon(colour, colour.lower() == active))
            b.setIconSize(QSize(28, 28))
            b.setToolTip(colour)
            b.clicked.connect(lambda _, c=colour: self.accent_chosen.emit(
                "" if c.lower() == info.default_accent.lower() else c))
            self.swatch_row.addWidget(b)
        custom = QPushButton(t("Custom colour"))
        custom.clicked.connect(self._pick_custom)
        self.swatch_row.addSpacing(10)
        self.swatch_row.addWidget(custom)
        self.swatch_row.addStretch()

    def _pick_custom(self) -> None:
        info = self.templates[self._current_template]
        c = QColorDialog.getColor(QColor(self._current_accent or info.default_accent), self,
                                  t("Accent colour"))
        if c.isValid():
            self.accent_chosen.emit(c.name())
