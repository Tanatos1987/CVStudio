"""
Main window: owns the current Profile and connects everything.

    +-------------+---------------------------+----------------------------+
    | nav rail    | editor page (stacked)     | live preview (Chromium)    |
    | profiles    |                           | CV / Letter toggle, zoom   |
    | sections    |                           |                            |
    | translate   |                           |                            |
    | import/export                           |                            |
    +-------------+---------------------------+----------------------------+

Edits are debounced: the preview re-renders 350 ms after the last
keystroke, the database write happens 900 ms after it. Closing the window
flushes any pending write.
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime
from pathlib import Path
from typing import Any

from PyQt6.QtCore import QRectF, QStandardPaths, Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QColor, QDesktopServices, QIcon, QImage, QKeySequence, QPainter, QShortcut
from PyQt6.QtWidgets import (QApplication, QButtonGroup, QComboBox, QFileDialog, QHBoxLayout, QInputDialog, QLabel,
                             QMainWindow, QMenu, QMessageBox, QProgressBar, QPushButton, QScrollArea,
                             QSplitter,
                             QStackedWidget, QToolButton, QVBoxLayout, QWidget)

from .. import cover_letter, cv_parser
from ..database import Database
from ..models import SECTIONS, Profile, sample_data
from ..paths import cache_dir, resource_root, templates_dir
from ..pdf_export import (PdfRenderer, export_with_weasyprint, pdf_first_page_png, pdf_page_count,
                          weasyprint_available)
from ..renderer import TemplateEngine, list_templates
from ..translator import CYRILLIC_RE
from . import theme
from .i18n import lang as ui_lang
from .i18n import t
from .import_dialog import ImportDialog
from .pages import CoverLetterPage, PersonalPage, SectionPage, TemplatesPage
from .photo import image_to_jpeg
from .preview import PreviewPanel
from .widgets import Toast
from .workers import ImportWorker, TranslateWorker, run_in_thread

NAV = [("personal", "Personal details"), ("experience", "Experience"), ("education", "Education"),
       ("skills", "Skills"), ("languages", "Languages"), ("certifications", "Certifications"),
       ("letter", "Cover letter"), ("design", "Design")]


def _safe_filename(text: str) -> str:
    text = re.sub(r"[^\w\s-]", "", text, flags=re.UNICODE).strip()
    return re.sub(r"\s+", "_", text) or "CV"


# --------------------------------------------------------------------------
# Small dialogs with translated buttons (Qt's own Yes/No/OK stay English
# when its translation files are not bundled).
# --------------------------------------------------------------------------
def ask_yes_no(parent, title: str, text: str) -> bool:
    box = QMessageBox(parent)
    box.setIcon(QMessageBox.Icon.Question)
    box.setWindowTitle(title)
    box.setText(text)
    yes = box.addButton(t("Yes"), QMessageBox.ButtonRole.YesRole)
    box.addButton(t("No"), QMessageBox.ButtonRole.NoRole)
    box.setDefaultButton(yes)
    box.exec()
    return box.clickedButton() is yes


def ask_text(parent, title: str, label: str, text: str = "") -> tuple[str, bool]:
    dlg = QInputDialog(parent)
    dlg.setWindowTitle(title)
    dlg.setLabelText(label)
    dlg.setTextValue(text)
    dlg.setOkButtonText(t("OK"))
    dlg.setCancelButtonText(t("Cancel"))
    ok = dlg.exec() == QInputDialog.DialogCode.Accepted
    return dlg.textValue(), ok


class MainWindow(QMainWindow):
    # Emitted with "bg" / "en"; main.py rebuilds the window in that language.
    language_switch_requested = pyqtSignal(str)

    def __init__(self, db: Database):
        super().__init__()
        self._restarting = False
        self.db = db
        self.engine = TemplateEngine()
        self.templates = list_templates()
        self.printer = PdfRenderer(self)
        self.printer.finished.connect(self._on_pdf_done)
        self.profile: Profile | None = None
        self.preview_kind = "cv"
        self._loading = False
        self._threads: list[Any] = []
        self._import_dialogs: list[ImportDialog] = []

        self.setWindowTitle("CV Studio")
        icon = resource_root() / "assets" / "icon.png"
        if icon.exists():
            self.setWindowIcon(QIcon(str(icon)))

        self._save_timer = QTimer(self, singleShot=True, interval=900, timeout=self.save_now)
        self._preview_timer = QTimer(self, singleShot=True, interval=350, timeout=self.refresh_preview)

        self._build_ui()
        self._build_shortcuts()
        self._load_initial_profile()
        QTimer.singleShot(400, self._build_thumbnails)

    # ==================================================================
    # UI construction
    # ==================================================================
    def _build_ui(self) -> None:
        root = QWidget()
        h = QHBoxLayout(root)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(0)
        h.addWidget(self._build_rail())

        self.stack = QStackedWidget()
        self.page_personal = PersonalPage()
        self.page_sections = {s.key: SectionPage(s) for s in SECTIONS}
        self.page_letter = CoverLetterPage()
        self.page_design = TemplatesPage(self.templates)
        self.pages = {"personal": self.page_personal, **self.page_sections,
                      "letter": self.page_letter, "design": self.page_design}
        for key, _ in NAV:
            self.stack.addWidget(self.pages[key])

        for page in self.pages.values():
            page.changed.connect(self._on_edit)
        self.page_personal.photo_changed.connect(self._on_photo)
        self.page_letter.generate_requested.connect(self.generate_letter)
        self.page_letter.today_requested.connect(self._letter_today)
        self.page_design.template_chosen.connect(self._on_template)
        self.page_design.accent_chosen.connect(self._on_accent)
        self.page_design.language_chosen.connect(self._on_labels_language)

        self.preview = PreviewPanel()
        self.preview.kind_changed.connect(self._on_preview_kind)

        self.split = QSplitter(Qt.Orientation.Horizontal)
        self.split.addWidget(self.stack)
        self.split.addWidget(self.preview)
        self.split.setStretchFactor(0, 5)
        self.split.setStretchFactor(1, 6)
        self.split.setHandleWidth(1)
        sizes = self.db.get_setting("splitter", "")
        self.split.setSizes([int(x) for x in sizes.split(",")] if sizes else [640, 700])
        h.addWidget(self.split, 1)
        self.setCentralWidget(root)
        self.toast = Toast(root)

    def _build_rail(self) -> QWidget:
        # The rail scrolls on short screens (1366x768 laptops) instead of
        # cutting off the export button.
        outer = QScrollArea()
        outer.setObjectName("NavRail")
        outer.setFixedWidth(250)
        outer.setWidgetResizable(True)
        outer.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        rail = QWidget()
        rail.setObjectName("NavRailInner")
        outer.setWidget(rail)
        v = QVBoxLayout(rail)
        v.setContentsMargins(16, 16, 14, 12)
        v.setSpacing(2)

        top = QHBoxLayout()
        mark = QLabel("CV Studio")
        mark.setObjectName("Wordmark")
        top.addWidget(mark, 1)
        # Interface language switch: two small segmented buttons.
        lang_group = QButtonGroup(self)
        for code, text, obj in (("bg", "БГ", "SegLeft"), ("en", "EN", "SegRight")):
            b = QPushButton(text)
            b.setObjectName(obj)
            b.setCheckable(True)
            b.setChecked(ui_lang() == code)
            b.setFixedSize(38, 28)
            b.setStyleSheet("padding: 0; font-size: 8.5pt; font-weight: 800;")
            b.setToolTip(t("Interface language"))
            b.clicked.connect(lambda _, c=code: c != ui_lang() and self.language_switch_requested.emit(c))
            lang_group.addButton(b)
            top.addWidget(b)
        v.addLayout(top)
        sub = QLabel(t("CV and cover letter, BG / EN"))
        sub.setObjectName("WordmarkSub")
        v.addWidget(sub)

        lbl = QLabel(t("CV version"))
        lbl.setObjectName("RailLabel")
        v.addWidget(lbl)
        row = QHBoxLayout()
        self.profile_box = QComboBox()
        self.profile_box.setToolTip(t("Keep a separate version for each application"))
        self.profile_box.activated.connect(self._on_profile_picked)
        more = QToolButton()
        more.setText("⋯")
        more.setToolTip(t("New, duplicate, rename or delete a version"))
        menu = QMenu(more)
        menu.addAction(t("New empty version"), self.new_profile)
        menu.addAction(t("Duplicate this version"), self.duplicate_profile)
        menu.addAction(t("Rename"), self.rename_profile)
        menu.addSeparator()
        menu.addAction(t("Delete"), self.delete_profile)
        more.setMenu(menu)
        more.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        row.addWidget(self.profile_box, 1)
        row.addWidget(more)
        v.addLayout(row)

        lbl = QLabel(t("Content"))
        lbl.setObjectName("RailLabel")
        v.addWidget(lbl)
        self.nav_group = QButtonGroup(self)
        self.nav_buttons: dict[str, QPushButton] = {}
        for i, (key, text) in enumerate(NAV):
            if key == "letter":
                spacer = QLabel(t("Extras"))
                spacer.setObjectName("RailLabel")
                v.addWidget(spacer)
            b = QPushButton(t(text))
            b.setObjectName("NavButton")
            b.setCheckable(True)
            b.clicked.connect(lambda _, idx=i: self.go_to(idx))
            self.nav_group.addButton(b)
            self.nav_buttons[key] = b
            v.addWidget(b)
        self.nav_buttons["personal"].setChecked(True)
        v.addStretch(1)

        lbl = QLabel(t("Translate everything"))
        lbl.setObjectName("RailLabel")
        v.addWidget(lbl)
        tr = QHBoxLayout()
        self.btn_bg_en = QPushButton("BG → EN")
        self.btn_en_bg = QPushButton("EN → BG")
        for b, src, tgt in ((self.btn_bg_en, "bg", "en"), (self.btn_en_bg, "en", "bg")):
            b.setObjectName("Translate")
            b.setToolTip(t("Translates every section. Bullets, line breaks, emails and links stay as they are."))
            b.clicked.connect(lambda _, s=src, g=tgt: self.translate(s, g))
            tr.addWidget(b)
        v.addLayout(tr)
        self.progress = QProgressBar()
        self.progress.setTextVisible(False)
        self.progress.setFixedHeight(6)
        self.progress.hide()
        v.addWidget(self.progress)

        v.addSpacing(10)
        imp = self.import_btn = QPushButton(t("Import old CV"))
        imp.setToolTip(t("PDF, Word (.docx), text file, or a photo / scan of your CV"))
        imp.clicked.connect(self.import_cv)
        v.addWidget(imp)

        self.export_btn = QPushButton(t("Export PDF"))
        self.export_btn.setObjectName("Primary")
        self.export_btn.setMinimumHeight(42)
        export_menu = QMenu(self.export_btn)
        export_menu.addAction(t("CV"), lambda: self.export("cv"))
        export_menu.addAction(t("Cover letter"), lambda: self.export("letter"))
        export_menu.addAction(t("CV and cover letter"), lambda: self.export("both"))
        if weasyprint_available():
            export_menu.addSeparator()
            export_menu.addAction(t("CV with WeasyPrint engine"), lambda: self.export("cv", engine="weasy"))
        self.export_btn.setMenu(export_menu)
        v.addWidget(self.export_btn)

        self.status = QLabel("")
        self.status.setObjectName("Status")
        v.addSpacing(4)
        v.addWidget(self.status)
        return outer

    def _build_shortcuts(self) -> None:
        QShortcut(QKeySequence("Ctrl+S"), self, activated=self.save_now)
        QShortcut(QKeySequence("Ctrl+E"), self, activated=lambda: self.export("cv"))
        QShortcut(QKeySequence("Ctrl+O"), self, activated=self.import_cv)
        for i in range(len(NAV)):
            QShortcut(QKeySequence(f"Ctrl+{i + 1}"), self, activated=lambda idx=i: self.go_to(idx))

    def go_to(self, index: int) -> None:
        self.stack.setCurrentIndex(index)
        key = NAV[index][0]
        self.nav_buttons[key].setChecked(True)
        if key == "letter" and self.preview_kind != "letter":
            self._on_preview_kind("letter")
        elif key not in ("letter", "design") and self.preview_kind != "cv":
            self._on_preview_kind("cv")

    # ==================================================================
    # Profiles
    # ==================================================================
    def _load_initial_profile(self) -> None:
        rows = self.db.list_profiles()
        if not rows:
            p = self.db.create(t("My CV"), language=ui_lang())
            rows = self.db.list_profiles()
            last = p.id
        else:
            last = int(self.db.get_setting("last_profile", "0") or 0)
            if last not in [r[0] for r in rows]:
                last = rows[0][0]
        self._reload_profile_list(last)
        self.load_profile(last)

    def _reload_profile_list(self, select_id: int | None = None) -> None:
        self.profile_box.blockSignals(True)
        self.profile_box.clear()
        for pid, name, _ in self.db.list_profiles():
            self.profile_box.addItem(name, pid)
        if select_id is not None:
            idx = self.profile_box.findData(select_id)
            self.profile_box.setCurrentIndex(max(0, idx))
        self.profile_box.blockSignals(False)

    def _on_profile_picked(self, index: int) -> None:
        pid = self.profile_box.itemData(index)
        if self.profile and pid != self.profile.id:
            self.save_now()
            self.load_profile(pid)

    def load_profile(self, pid: int) -> None:
        profile = self.db.load(pid)
        if not profile:
            return
        self.profile = profile
        self._loading = True
        self.page_personal.set(profile.data["personal"])
        self.page_personal.photo.set_photo(profile.photo, profile.photo_original)
        for key, page in self.page_sections.items():
            page.set(profile.data.get(key, []))
        self.page_letter.set(profile.data["cover_letter"])
        self.page_design.set_state(profile.template, profile.accent, profile.language)
        self._loading = False
        self.db.set_setting("last_profile", str(pid))
        self.status.setText(t("Opened {name}", name=profile.name))
        self.refresh_preview(keep_scroll=False)

    def new_profile(self) -> None:
        name, ok = ask_text(self, t("New version"), t("Name, e.g. the company you apply to:"))
        if ok and name.strip():
            self.save_now()
            p = self.db.create(name.strip())
            self._reload_profile_list(p.id)
            self.load_profile(p.id)
            self.go_to(0)

    def duplicate_profile(self) -> None:
        if not self.profile:
            return
        self.save_now()
        name, ok = ask_text(self, t("Duplicate"), t("Name of the copy:"),
                            text=t("{name} (copy)", name=self.profile.name))
        if ok and name.strip():
            p = self.db.duplicate(self.profile.id, name.strip())
            self._reload_profile_list(p.id)
            self.load_profile(p.id)
            self.toast.show_message(t("Copy created"))

    def rename_profile(self) -> None:
        if not self.profile:
            return
        name, ok = ask_text(self, t("Rename"), t("New name:"), text=self.profile.name)
        if ok and name.strip():
            self.profile.name = name.strip()
            self.save_now()
            self._reload_profile_list(self.profile.id)

    def delete_profile(self) -> None:
        if not self.profile:
            return
        if len(self.db.list_profiles()) == 1:
            self.toast.show_message(t("Keep at least one version. Create another one first."), error=True)
            return
        if ask_yes_no(self, t("Delete version"),
                      t("Delete \"{name}\"? This cannot be undone.", name=self.profile.name)):
            self._save_timer.stop()
            self.db.delete(self.profile.id)
            self.profile = None
            rows = self.db.list_profiles()
            self._reload_profile_list(rows[0][0])
            self.load_profile(rows[0][0])

    # ==================================================================
    # Editing
    # ==================================================================
    def collect(self) -> None:
        """Pull every page's values into the Profile object."""
        if not self.profile:
            return
        d = self.profile.data
        d["personal"] = self.page_personal.get()
        for key, page in self.page_sections.items():
            d[key] = page.get()
        d["cover_letter"] = self.page_letter.get()

    def _on_edit(self) -> None:
        if self._loading:
            return
        self.collect()
        self.status.setText(t("Unsaved changes"))
        self._save_timer.start()
        self._preview_timer.start()

    def _on_photo(self, cropped: bytes | None, original: bytes | None) -> None:
        if not self.profile:
            return
        self.profile.photo, self.profile.photo_original = cropped, original
        self._save_timer.start()
        self.refresh_preview()

    def _on_template(self, template_id: str) -> None:
        if not self.profile or template_id == self.profile.template:
            return
        self.profile.template = template_id
        self.profile.accent = ""  # each design starts from its own default colour
        self.page_design.set_state(self.profile.template, self.profile.accent, self.profile.language)
        self._save_timer.start()
        self.refresh_preview(keep_scroll=False)

    def _on_accent(self, colour: str) -> None:
        if not self.profile:
            return
        self.profile.accent = colour
        self.page_design.set_state(self.profile.template, colour, self.profile.language)
        self._save_timer.start()
        self.refresh_preview()

    def _on_labels_language(self, lang: str) -> None:
        if self.profile and lang != self.profile.language:
            self.profile.language = lang
            self._save_timer.start()
            self.refresh_preview()

    def _on_preview_kind(self, kind: str) -> None:
        self.preview_kind = kind
        self.preview.set_kind(kind)
        self.refresh_preview(keep_scroll=False)

    def save_now(self) -> None:
        self._save_timer.stop()
        if not self.profile:
            return
        if not self._loading:
            self.collect()
        stamp = self.db.save(self.profile)
        self.status.setText(t("Saved {time}", time=f"{datetime.fromisoformat(stamp):%H:%M}"))

    def refresh_preview(self, keep_scroll: bool = True) -> None:
        if not self.profile:
            return
        try:
            path = self.engine.render_to_file(self.profile, self.preview_kind,
                                              name=f"preview_{self.preview_kind}.html")
        except Exception as exc:  # a broken custom template must not kill the app
            self.toast.show_message(t("Template error: {error}", error=exc), 6000, error=True)
            return
        self.preview.show_file(path, keep_scroll=keep_scroll)

    # ==================================================================
    # Cover letter
    # ==================================================================
    def generate_letter(self) -> None:
        if not self.profile:
            return
        self.collect()
        letter = self.profile.data["cover_letter"]
        if letter.get("body", "").strip():
            if not ask_yes_no(self, t("Replace letter text"),
                              t("Replace the current letter text with a new draft?")):
                return
        letter["body"] = cover_letter.generate(self.profile.data, self.profile.language)
        if not letter.get("date"):
            letter["date"] = cover_letter.today_string(self.profile.language)
        self._loading = True
        self.page_letter.set(letter)
        self._loading = False
        self._on_preview_kind("letter")
        self._save_timer.start()
        self.toast.show_message(t("Draft written. Edit it so it sounds like you."))

    def _letter_today(self) -> None:
        if not self.profile:
            return
        self.page_letter.fields["date"].set_value(cover_letter.today_string(self.profile.language))
        self._on_edit()

    # ==================================================================
    # Translation
    # ==================================================================
    def translate(self, src: str, tgt: str) -> None:
        if not self.profile:
            return
        self.save_now()
        data = self.profile.data
        flat = str(data)
        has_cyr = bool(CYRILLIC_RE.search(flat))
        if src == "bg" and not has_cyr:
            self.toast.show_message(t("No Bulgarian text found in this CV."), error=True)
            return
        if src == "en" and not re.search(r"[A-Za-z]{3,}", re.sub(r"\S+@\S+|https?://\S+", "", flat)):
            self.toast.show_message(t("No English text found in this CV."), error=True)
            return

        box = QMessageBox(self)
        box.setWindowTitle(t("Translate"))
        target_name = t("English") if tgt == "en" else t("Bulgarian")
        box.setText(t("Translate \"{name}\" into {language}?", name=self.profile.name, language=target_name))
        box.setInformativeText(t("A copy keeps the original untouched, so you have both language versions."))
        copy_btn = box.addButton(t("Create translated copy"), QMessageBox.ButtonRole.AcceptRole)
        inplace_btn = box.addButton(t("Translate this version"), QMessageBox.ButtonRole.DestructiveRole)
        box.addButton(t("Cancel"), QMessageBox.ButtonRole.RejectRole)
        box.setDefaultButton(copy_btn)
        box.exec()
        clicked = box.clickedButton()
        if clicked not in (copy_btn, inplace_btn):
            return
        as_copy = clicked is copy_btn

        self._set_busy(True, t("Translating to {language}...", language=target_name))
        worker = TranslateWorker(data, src, tgt)
        worker.progress.connect(lambda a, b: (self.progress.setRange(0, b), self.progress.setValue(a)))
        worker.finished.connect(lambda result: self._translation_done(result, tgt, as_copy))
        worker.failed.connect(self._translation_failed)
        self._threads.append((run_in_thread(worker, self), worker))

    def _translation_done(self, result: dict, tgt: str, as_copy: bool) -> None:
        self._set_busy(False)
        suffix = " (EN)" if tgt == "en" else " (BG)"
        if as_copy:
            base = re.sub(r"\s\((EN|BG)\)$", "", self.profile.name)
            new = self.db.duplicate(self.profile.id, base + suffix)
            new.data, new.language = result, tgt
            self.db.save(new)
            self._reload_profile_list(new.id)
            self.load_profile(new.id)
        else:
            self.profile.data, self.profile.language = result, tgt
            self.db.save(self.profile)
            self.load_profile(self.profile.id)
        self.toast.show_message(t("Translated to {language}. Names were transliterated, check them once.",
                                  language=t("English") if tgt == "en" else t("Bulgarian")), 4200)

    def _translation_failed(self, message: str) -> None:
        self._set_busy(False)
        QMessageBox.warning(self, t("Translation failed"),
                            t("The translation service could not be reached. Check the internet "
                              "connection and try again.") + "\n\n" + message)

    def _set_busy(self, busy: bool, text: str = "") -> None:
        for b in (self.btn_bg_en, self.btn_en_bg, self.export_btn, self.import_btn):
            b.setEnabled(not busy)
        self.progress.setVisible(busy)
        self.progress.setRange(0, 0)  # indeterminate until the first chunk returns
        if text:
            self.status.setText(text)

    # ==================================================================
    # Import
    # ==================================================================
    def import_cv(self) -> None:
        path, _ = QFileDialog.getOpenFileName(
            self, t("Import an old CV"), "",
            t("CV files") + " (*.pdf *.docx *.txt *.md *.jpg *.jpeg *.png);;"
            + t("Images") + " (*.jpg *.jpeg *.png *.bmp *.tif *.tiff *.webp);;"
            + t("All files") + " (*)")
        if not path:
            return
        # Reading runs in the background: scanned PDFs and photos go through
        # OCR, which takes a few seconds per page.
        self._set_busy(True, t("Reading the file..."))
        worker = ImportWorker(path)
        worker.finished.connect(self._import_parsed)
        worker.failed.connect(self._import_failed)
        self._threads.append((run_in_thread(worker, self), worker))

    def _import_failed(self, exc: Exception) -> None:
        self._set_busy(False)
        self.status.setText("")
        if isinstance(exc, cv_parser.ParseError):
            kwargs = {k: str(v) for k, v in exc.kwargs.items()}
            QMessageBox.warning(self, t("Import"), t(exc.key, **kwargs))
        else:
            QMessageBox.warning(self, t("Import"), str(exc))

    def _import_parsed(self, parsed) -> None:
        self._set_busy(False)
        self.status.setText("")
        dlg = ImportDialog(parsed, self)
        dlg.apply_requested.connect(self._apply_import)
        dlg.finished.connect(lambda _: self._import_dialogs.remove(dlg))
        self._import_dialogs.append(dlg)
        dlg.show()

    def _apply_import(self, payload: dict) -> None:
        if not self.profile:
            return
        self.collect()
        d = self.profile.data
        d["personal"].update(payload.get("personal", {}))
        if payload.get("summary"):
            d["personal"]["summary"] = payload["summary"]
        for key in ("experience", "education", "skills", "languages", "certifications"):
            if payload.get(key):
                d[key].extend(payload[key])
        self.load_profile_from_memory()
        self._save_timer.start()
        if payload.get("photo"):
            self.page_personal.photo.open_bytes(payload["photo"])
        self.toast.show_message(t("Imported. Review each section, the parser only guesses."))

    def load_profile_from_memory(self) -> None:
        """Refresh all pages from self.profile without touching the database."""
        p = self.profile
        self._loading = True
        self.page_personal.set(p.data["personal"])
        for key, page in self.page_sections.items():
            page.set(p.data.get(key, []))
        self.page_letter.set(p.data["cover_letter"])
        self._loading = False
        self.refresh_preview()

    # ==================================================================
    # Export
    # ==================================================================
    def export(self, what: str, engine: str = "chromium") -> None:
        if not self.profile:
            return
        self.save_now()
        name = _safe_filename(self.profile.data["personal"].get("full_name") or self.profile.name)
        lang = self.profile.language.upper()
        folder = self.db.get_setting("export_dir", "") or \
            QStandardPaths.writableLocation(QStandardPaths.StandardLocation.DocumentsLocation)
        default = Path(folder) / f"{name}_{'Cover_Letter' if what == 'letter' else 'CV'}_{lang}.pdf"
        path, _ = QFileDialog.getSaveFileName(self, t("Export PDF"), str(default), "PDF (*.pdf)")
        if not path:
            return
        target = Path(path).with_suffix(".pdf")
        self.db.set_setting("export_dir", str(target.parent))

        jobs = []
        if what in ("cv", "both"):
            jobs.append(("cv", target))
        if what in ("letter", "both"):
            letter_path = target if what == "letter" else \
                target.with_name(target.stem.replace("_CV", "") + "_Cover_Letter.pdf")
            jobs.append(("letter", letter_path))

        self._pending_exports = len(jobs)
        for kind, out in jobs:
            html = self.engine.render_to_file(self.profile, kind, name=f"export_{kind}.html")
            if engine == "weasy":
                try:
                    export_with_weasyprint(html, out)
                    self._on_pdf_done(str(out), True, ("export", kind))
                except Exception as exc:
                    QMessageBox.warning(self, "WeasyPrint", t("WeasyPrint failed: {error}", error=exc))
                continue
            self.status.setText(t("Exporting PDF..."))
            self.printer.render(html, out, tag=("export", kind))

    def _on_pdf_done(self, path: str, ok: bool, tag: Any) -> None:
        kind = tag[0] if isinstance(tag, tuple) else ""
        if kind == "thumb":
            self._on_thumb_done(path, ok, tag[1])
            return
        if not ok:
            QMessageBox.warning(self, t("Export"), t("The PDF could not be written to:\n{path}\n\n"
                                                     "Close it if it is open in a PDF viewer and try again.", path=path))
            return
        pages = pdf_page_count(Path(path))
        self.status.setText(t("Exported {name}", name=Path(path).name))
        self.toast.show_message(t("Exported {name}, {pages} pages" if pages > 1 else "Exported {name}, {pages} page",
                                  name=Path(path).name, pages=pages))
        self._pending_exports = getattr(self, "_pending_exports", 1) - 1
        if self._pending_exports <= 0:
            QDesktopServices.openUrl(QUrl.fromLocalFile(path))

    # ==================================================================
    # Template gallery thumbnails (real renders, cached per template version)
    # ==================================================================
    def _template_version(self, template_id: str) -> str:
        h = hashlib.sha1()
        for folder in (templates_dir() / template_id, templates_dir() / "_shared"):
            for f in sorted(folder.glob("*")):
                # Content, not mtime: the .exe unpacks files with fresh dates on every start.
                h.update(f.name.encode() + f.read_bytes())
        return h.hexdigest()[:10]

    def _build_thumbnails(self) -> None:
        thumbs = cache_dir("thumbs")
        photo = self._sample_photo()
        for tpl in self.templates:
            png = thumbs / f"{tpl.id}_{ui_lang()}_{self._template_version(tpl.id)}.png"
            if png.exists():
                self.page_design.set_thumbnail(tpl.id, png)
                continue
            sample = Profile(id=None, name="sample", template=tpl.id, data=sample_data(ui_lang()),
                             language=ui_lang(), photo=photo)
            html = self.engine.render_to_file(sample, "cv", name=f"thumb_{tpl.id}.html")
            self.printer.render(html, png.with_suffix(".pdf"), tag=("thumb", tpl.id))

    def _on_thumb_done(self, pdf: str, ok: bool, template_id: str) -> None:
        if not ok:
            return
        png = Path(pdf).with_suffix(".png")
        pdf_first_page_png(Path(pdf), png, width_px=440)
        Path(pdf).unlink(missing_ok=True)
        self.page_design.set_thumbnail(template_id, png)

    @staticmethod
    def _sample_photo() -> bytes:
        """An abstract portrait so gallery thumbnails show the photo frame."""
        img = QImage(480, 480, QImage.Format.Format_RGB32)
        p = QPainter(img)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(0, 0, 480, 480, QColor("#b9c3cc"))
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor("#3e3431"))
        p.drawEllipse(QRectF(140, 70, 200, 240))
        p.setBrush(QColor("#dcb49a"))
        p.drawEllipse(QRectF(165, 110, 150, 185))
        p.setBrush(QColor("#34495e"))
        p.drawEllipse(QRectF(70, 320, 340, 320))
        p.end()
        return image_to_jpeg(img)

    # ==================================================================
    def showEvent(self, e):
        super().showEvent(e)
        theme.dark_title_bar(self)

    def closeEvent(self, e):
        for thread, _worker in self._threads:
            if thread.isRunning():
                thread.quit()
                thread.wait(3000)
        self.save_now()
        self.db.set_setting("splitter", ",".join(str(s) for s in self.split.sizes()))
        super().closeEvent(e)
        self.printer.view.close()
        if not self._restarting:
            QApplication.quit()

    def show_sized(self) -> None:
        """Fit the first window to the screen; small laptop screens get maximised."""
        avail = self.screen().availableGeometry()
        if avail.width() < 1500 or avail.height() < 900:
            self.resize(min(1400, avail.width()), min(900, avail.height()))
            self.showMaximized()
        else:
            self.resize(1560, 940)
            self.show()
