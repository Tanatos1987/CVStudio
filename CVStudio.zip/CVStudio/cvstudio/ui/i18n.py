"""
Interface language (Bulgarian / English).

Source strings in the code are English and wrapped in ``t()``. When the
interface language is Bulgarian, ``t()`` looks the string up in ``BG``;
anything missing falls back to English, so a forgotten entry never breaks
the UI. Placeholders use str.format: t("Saved {time}", time="14:02").

This is separate from the CV language: the interface can be Bulgarian
while you write an English CV, and the other way round.
"""
from __future__ import annotations

_LANG = "bg"


def set_language(lang: str) -> None:
    global _LANG
    _LANG = "bg" if lang == "bg" else "en"


def lang() -> str:
    return _LANG


def t(text: str, **kwargs) -> str:
    s = BG.get(text, text) if _LANG == "bg" else text
    return s.format(**kwargs) if kwargs else s


BG: dict[str, str] = {
    # ---- navigation rail ------------------------------------------------
    "CV and cover letter, BG / EN": "CV и мотивационно писмо, BG / EN",
    "CV version": "Версия на CV",
    "Keep a separate version for each application": "Отделна версия за всяка кандидатура",
    "New, duplicate, rename or delete a version": "Нова версия, копие, преименуване или изтриване",
    "New empty version": "Нова празна версия",
    "Duplicate this version": "Копирай тази версия",
    "Rename": "Преименувай",
    "Delete": "Изтрий",
    "Content": "Съдържание",
    "Extras": "Допълнително",
    "Personal details": "Лични данни",
    "Experience": "Опит",
    "Education": "Образование",
    "Skills": "Умения",
    "Languages": "Езици",
    "Certifications": "Сертификати",
    "Cover letter": "Мотивационно писмо",
    "Design": "Дизайн",
    "Translate everything": "Преведи цялото CV",
    "Translates every section. Bullets, line breaks, emails and links stay as they are.":
        "Превежда всички секции. Булетите, редовете, имейлите и линковете остават непроменени.",
    "Import old CV": "Импорт на старо CV",
    "PDF, Word (.docx) or text file": "PDF, Word (.docx) или текстов файл",
    "Export PDF": "Експорт в PDF",
    "CV": "CV",
    "CV and cover letter": "CV и мотивационно писмо",
    "CV with WeasyPrint engine": "CV с WeasyPrint",
    "Interface language": "Език на менюто",

    # ---- status / toasts --------------------------------------------------
    "Opened {name}": "Отворено: {name}",
    "Unsaved changes": "Има незаписани промени",
    "Saved {time}": "Записано в {time}",
    "Exporting PDF...": "Създавам PDF...",
    "Exported {name}": "Готово: {name}",
    "Exported {name}, {pages} page": "Готово: {name}, {pages} страница",
    "Exported {name}, {pages} pages": "Готово: {name}, {pages} страници",
    "Copy created": "Копието е създадено",
    "Template error: {error}": "Грешка в шаблона: {error}",
    "Keep at least one version. Create another one first.":
        "Трябва да остане поне една версия. Първо създайте друга.",
    "Imported. Review each section, the parser only guesses.":
        "Импортирано. Прегледайте всяка секция, разпознаването е приблизително.",
    "Draft written. Edit it so it sounds like you.":
        "Черновата е готова. Редактирайте я, за да звучи като вас.",

    # ---- profile dialogs --------------------------------------------------
    "New version": "Нова версия",
    "Name, e.g. the company you apply to:": "Име, например компанията, в която кандидатствате:",
    "Duplicate": "Копие",
    "Name of the copy:": "Име на копието:",
    "{name} (copy)": "{name} (копие)",
    "New name:": "Ново име:",
    "Delete version": "Изтриване на версия",
    "Delete \"{name}\"? This cannot be undone.": "Да изтрия ли „{name}“? Това не може да се отмени.",
    "My CV": "Моето CV",

    # ---- cover letter -----------------------------------------------------
    "Replace letter text": "Замяна на текста",
    "Replace the current letter text with a new draft?": "Да заменя ли текущия текст с нова чернова?",
    "Uses the same design, colours and header as your CV. Switch the preview to Letter to see it.":
        "Използва същия дизайн, цветове и заглавна част като CV-то. Превключете прегледа на „Писмо“, за да го видите.",
    "Write a draft from my CV": "Напиши чернова от моето CV",
    "Builds a first draft from your latest job, strongest results and top skills":
        "Съставя чернова от последната ви позиция, най-силните резултати и уменията",
    "Use today's date": "Днешна дата",

    # ---- translation ------------------------------------------------------
    "No Bulgarian text found in this CV.": "В това CV няма текст на български.",
    "No English text found in this CV.": "В това CV няма текст на английски.",
    "Translate": "Превод",
    "English": "английски",
    "Bulgarian": "български",
    "Translate \"{name}\" into {language}?": "Да преведа ли „{name}“ на {language}?",
    "A copy keeps the original untouched, so you have both language versions.":
        "Копието запазва оригинала непроменен и получавате двете езикови версии.",
    "Create translated copy": "Създай преведено копие",
    "Translate this version": "Преведи тази версия",
    "Translating to {language}...": "Превеждам на {language}...",
    "Translated to {language}. Names were transliterated, check them once.":
        "Преведено на {language}. Имената са транслитерирани, проверете ги.",
    "Translation failed": "Преводът не успя",
    "The translation service could not be reached. Check the internet connection and try again.":
        "Услугата за превод не отговаря. Проверете интернет връзката и опитайте отново.",

    # ---- import -----------------------------------------------------------
    "Import an old CV": "Импорт на старо CV",
    "Reading the file...": "Чета файла...",
    "PDF, Word (.docx), text file, or a photo / scan of your CV":
        "PDF, Word (.docx), текстов файл или снимка / сканиран вариант на CV-то",
    "This file is a scan or an image, so the text was recognised with OCR. "
    "Check names, numbers and dates for recognition errors.":
        "Файлът е сканиран или е изображение и текстът е разпознат автоматично (OCR). "
        "Проверете имената, числата и датите за грешки.",
    "The PDF could not be opened: {error}": "PDF файлът не може да се отвори: {error}",
    "The image could not be opened: {error}": "Изображението не може да се отвори: {error}",
    "The Word file could not be opened: {error}": "Word файлът не може да се отвори: {error}",
    "Text recognition (OCR) files are missing. Run install_and_run.bat rebuild.":
        "Липсват файловете за разпознаване на текст (OCR). Пуснете install_and_run.bat rebuild.",
    "Text recognition (OCR) failed: {error}": "Разпознаването на текст (OCR) не успя: {error}",
    "No text could be read from this file, not even with OCR. Use a sharper scan, or a PDF "
    "exported directly from Word or the CV website.":
        "От файла не може да се прочете текст дори с OCR. Използвайте по-ясно сканиране или PDF, "
        "запазен директно от Word или от сайта, в който е правено CV-то.",
    "Old .doc files are not supported. Open the file in Word and use File > Save As > Word "
    "Document (.docx), then import that file.":
        "Старите .doc файлове не се поддържат. Отворете файла в Word, изберете File > Save As > "
        "Word Document (.docx) и импортирайте новия файл.",
    "Unsupported file type: {ext}": "Този тип файл не се поддържа: {ext}",
    "CV files": "CV файлове",
    "All files": "Всички файлове",
    "Import": "Импорт",
    "Import: {file}": "Импорт: {file}",
    "Select any text on the left and press Ctrl+C to paste it into a field. "
    "Tick what was recognised on the right and add it to your CV.":
        "Маркирайте текст вляво и натиснете Ctrl+C, за да го поставите в поле. "
        "Отметнете разпознатото вдясно и го добавете към CV-то.",
    "Close": "Затвори",
    "Add checked items to CV": "Добави отбелязаното в CV",
    "Photo found in the file": "Снимка от файла",
    "Use as profile photo (you can crop it next)": "Използвай като профилна снимка (ще може да я изрежете)",
    "Contact details": "Контакти",
    "Profile": "Профил",
    "Name": "Име",
    "Email": "Имейл",
    "Phone": "Телефон",
    "Website": "Уебсайт",
    "(untitled block)": "(блок без заглавие)",
    "No sections were recognised automatically. Copy what you need from the text on the left.":
        "Не бяха разпознати секции. Копирайте нужното от текста вляво.",

    # ---- export -----------------------------------------------------------
    "Export": "Експорт",
    "The PDF could not be written to:\n{path}\n\nClose it if it is open in a PDF viewer and try again.":
        "PDF файлът не може да се запише в:\n{path}\n\nЗатворете го, ако е отворен в програма за PDF, и опитайте отново.",
    "WeasyPrint failed: {error}": "WeasyPrint не успя: {error}",

    # ---- pages ------------------------------------------------------------
    "The basics recruiters scan first. Empty fields are left out of the CV.":
        "Основното, което работодателите гледат първо. Празните полета не се показват в CV-то.",
    "Two or three sentences: what you do, for whom, and one result with a number in it.":
        "Две-три изречения: с какво се занимавате, за кого и един резултат с конкретно число.",
    "Newest first. Start each achievement with a verb and keep one per line.":
        "Най-новото най-горе. Започвайте всяко постижение с глагол, по едно на ред.",
    "Degrees, schools and notable training.": "Степени, учебни заведения и важни обучения.",
    "The level drives the meters, dots or highlighted pills, depending on the design.":
        "Нивото се показва като скала, точки или подчертан етикет според дизайна.",
    "Use CEFR levels (A1-C2) or words like Native.": "Използвайте нивата A1-C2 или думи като „роден“.",
    "Licences, certificates and courses worth showing.": "Лицензи, сертификати и курсове, които си струва да покажете.",
    "Pick a layout, then a colour. The preview and the exported PDF use the same rendering "
    "engine, so what you see is what prints.":
        "Изберете оформление, после цвят. Прегледът и PDF файлът се създават от един и същ "
        "механизъм, така че каквото виждате, това се отпечатва.",
    "Accent colour": "Акцентен цвят",
    "Custom colour": "Друг цвят",
    "Section headings language": "Език на заглавията в CV-то",
    "Headings switch automatically when you translate the CV. Change them here if you write the "
    "content in one language by hand.":
        "Заглавията се сменят сами при превод на CV-то. Променете ги тук, ако пишете "
        "съдържанието ръчно на един език.",
    "Rendering preview...": "Подготвям преглед...",

    # ---- entry cards ------------------------------------------------------
    "Show or hide the fields": "Покажи или скрий полетата",
    "Move up": "Премести нагоре",
    "Move down": "Премести надолу",
    "Remove this entry": "Премахни записа",
    "New entry": "Нов запис",

    # ---- field placeholders (models.py) -----------------------------------
    "Financial Controller": "Финансов контрольор",
    "Present": "Настояще",
    "Varna, Bulgaria": "Варна, България",
    "• Cut breakfast food cost from 31% to 26% in one season\n"
    "• Rebuilt the supplier price list for 140 SKUs":
        "• Намалих разхода за храна на закуската от 31% на 26% за един сезон\n"
        "• Обнових ценовата листа на доставчиците за 140 артикула",
    "MSc Accounting and Control": "Магистър, Счетоводство и контрол",
    "University of Economics - Varna": "Икономически университет - Варна",
    "C1 - fluent": "C1 - свободно",
    "Financial Controller, Hospitality": "Финансов контрольор, хотелиерство",
    "Hiring Manager": "Отговорник подбор",
    "Aqua Hotel Varna": "Аква Хотел Варна",

    # ---- photo ------------------------------------------------------------
    "Crop photo": "Изрязване на снимка",
    "Drag to position, scroll to zoom. Keep the eyes near the upper guide line.":
        "Плъзнете, за да наместите, и използвайте колелцето за мащаб. Очите да са близо до горната линия.",
    "Zoom": "Мащаб",
    "Cancel": "Отказ",
    "Yes": "Да",
    "No": "Не",
    "OK": "Добре",
    "Use photo": "Използвай снимката",
    "Profile photo": "Профилна снимка",
    "JPG or PNG. A plain background and soft daylight print best.":
        "JPG или PNG. Най-добре изглежда снимка с изчистен фон и мека дневна светлина.",
    "Upload photo": "Качи снимка",
    "Crop again": "Изрежи отново",
    "Remove": "Премахни",
    "Choose a photo": "Изберете снимка",
    "Images": "Изображения",

    # ---- preview ----------------------------------------------------------
    "Letter": "Писмо",
    "Zoom out": "Намали",
    "Zoom in": "Увеличи",
    "Fit page width": "Цяла ширина на страницата",
    "Fit": "Цяла",
    "Fit {pct}%": "Цяла {pct}%",
    "{n} page": "{n} страница",
    "{n} pages": "{n} страници",
    "The preview engine stopped. Reloading...": "Прегледът спря. Зареждам отново...",
    "The preview could not be displayed.": "Прегледът не може да се покаже.",
}
