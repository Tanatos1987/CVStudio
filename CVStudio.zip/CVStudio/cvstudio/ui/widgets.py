"""
Reusable widgets for the editor.

The list sections (Experience, Education, ...) are generated from the
``SectionSpec`` definitions in models.py, so adding a field to a section is a
one-line change there and the form, translator and templates pick it up.
"""
from __future__ import annotations

import re
from typing import Any

from PyQt6.QtCore import QEasingCurve, QPropertyAnimation, Qt, QTimer, pyqtSignal
from PyQt6.QtGui import QKeyEvent, QTextCursor
from PyQt6.QtWidgets import (QFrame, QGraphicsOpacityEffect, QGridLayout, QHBoxLayout, QLabel,
                             QLineEdit, QPlainTextEdit, QPushButton, QSizePolicy, QSlider,
                             QToolButton, QVBoxLayout, QWidget)

from ..models import FieldSpec, SectionSpec
from .i18n import lang as ui_lang
from .i18n import t

LEVEL_NAMES = {
    "en": ["Not shown", "Basic", "Working", "Good", "Advanced", "Expert"],
    "bg": ["Не се показва", "Основно", "Работно", "Добро", "Напреднало", "Експертно"],
}

_BULLET = re.compile(r"^(\s*)([•●▪◦*\-]|\d{1,2}[.)])(\s+)(.*)$")


# --------------------------------------------------------------------------
# Multi-line editor that understands bullets
# --------------------------------------------------------------------------
class BulletTextEdit(QPlainTextEdit):
    """
    * Enter on a bullet line starts the next bullet ("• ", "2. ", ...).
    * Enter on an empty bullet ends the list.
    * Typing "- " or "* " at the start of a line turns it into "• ".
    * Grows with its content so the page scrolls, not the field.
    """

    def __init__(self, placeholder: str = "", min_lines: int = 3, parent: QWidget | None = None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setTabChangesFocus(True)
        self._min_lines = min_lines
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.document().contentsChanged.connect(self._fit)
        self._fit()

    def _fit(self) -> None:
        line_h = self.fontMetrics().lineSpacing()
        lines = max(self._min_lines, int(self.document().size().height()) + 1)
        self.setFixedHeight(min(lines, 18) * line_h + 18)

    def resizeEvent(self, e):  # re-wrap changes the line count
        super().resizeEvent(e)
        QTimer.singleShot(0, self._fit)

    def keyPressEvent(self, e: QKeyEvent) -> None:
        cursor = self.textCursor()
        line = cursor.block().text()

        if e.key() == Qt.Key.Key_Space and cursor.positionInBlock() == len(line) \
                and line.strip() in ("-", "*"):
            cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock,
                                QTextCursor.MoveMode.KeepAnchor)
            cursor.insertText(line[: len(line) - len(line.lstrip())] + "• ")
            return

        if e.key() in (Qt.Key.Key_Return, Qt.Key.Key_Enter) and \
                not e.modifiers() & Qt.KeyboardModifier.ShiftModifier:
            m = _BULLET.match(line)
            if m:
                indent, marker, space, body = m.groups()
                if not body.strip():  # empty bullet -> leave the list
                    cursor.movePosition(QTextCursor.MoveOperation.StartOfBlock,
                                        QTextCursor.MoveMode.KeepAnchor)
                    cursor.removeSelectedText()
                    return
                if marker[:-1].isdigit():
                    marker = f"{int(marker[:-1]) + 1}{marker[-1]}"
                cursor.insertText("\n" + indent + marker + space)
                return
        super().keyPressEvent(e)


# --------------------------------------------------------------------------
# Labelled field
# --------------------------------------------------------------------------
class Field(QWidget):
    changed = pyqtSignal()

    def __init__(self, spec: FieldSpec, lang: str | None = None, parent: QWidget | None = None):
        super().__init__(parent)
        self.spec = spec
        self.lang = lang = lang or ui_lang()
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(5)
        self.label = QLabel(spec.label_bg if lang == "bg" else spec.label_en)
        self.label.setObjectName("FieldLabel")
        lay.addWidget(self.label)

        if spec.kind == "text":
            self.editor: QWidget = BulletTextEdit(t(spec.placeholder) if spec.placeholder else "")
            self.editor.textChanged.connect(self.changed)
        elif spec.kind == "level":
            row = QWidget()
            h = QHBoxLayout(row)
            h.setContentsMargins(0, 4, 0, 0)
            self.editor = QSlider(Qt.Orientation.Horizontal)
            self.editor.setRange(0, 5)
            self.editor.setPageStep(1)
            self._level_label = QLabel()
            self._level_label.setObjectName("Muted")
            self._level_label.setMinimumWidth(96)
            self.editor.valueChanged.connect(self._on_level)
            h.addWidget(self.editor, 1)
            h.addWidget(self._level_label)
            lay.addWidget(row)
            self._on_level(0, emit=False)
            return
        else:
            self.editor = QLineEdit()
            self.editor.setPlaceholderText(t(spec.placeholder) if spec.placeholder else "")
            self.editor.textChanged.connect(self.changed)
        self.label.setBuddy(self.editor)
        lay.addWidget(self.editor)

    def _on_level(self, v: int, emit: bool = True) -> None:
        self._level_label.setText(LEVEL_NAMES.get(self.lang, LEVEL_NAMES["en"])[v])
        if emit:
            self.changed.emit()

    def value(self) -> Any:
        if isinstance(self.editor, QSlider):
            return self.editor.value()
        if isinstance(self.editor, QPlainTextEdit):
            return self.editor.toPlainText()
        return self.editor.text()

    def set_value(self, v: Any) -> None:
        self.editor.blockSignals(True)
        if isinstance(self.editor, QSlider):
            self.editor.setValue(int(v or 0))
            self._on_level(int(v or 0), emit=False)
        elif isinstance(self.editor, QPlainTextEdit):
            self.editor.setPlainText(v or "")
        else:
            self.editor.setText(v or "")
            self.editor.setCursorPosition(0)
        self.editor.blockSignals(False)


# --------------------------------------------------------------------------
# One entry (a job, a degree, a skill...)
# --------------------------------------------------------------------------
class EntryCard(QFrame):
    changed = pyqtSignal()
    remove_requested = pyqtSignal(object)
    move_requested = pyqtSignal(object, int)

    def __init__(self, spec: SectionSpec, lang: str, expanded: bool = True, parent=None):
        super().__init__(parent)
        self.spec = spec
        self.setObjectName("EntryCard")
        outer = QVBoxLayout(self)
        outer.setContentsMargins(14, 10, 10, 12)
        outer.setSpacing(8)

        # Header: title + actions
        head = QHBoxLayout()
        self.toggle = QToolButton()
        self.toggle.setCheckable(True)
        self.toggle.setToolTip(t("Show or hide the fields"))
        self.toggle.clicked.connect(lambda c: self.set_expanded(c))
        self.title = QLabel()
        self.title.setObjectName("CardTitle")
        self.sub = QLabel()
        self.sub.setObjectName("CardSub")
        titles = QVBoxLayout()
        titles.setSpacing(0)
        titles.addWidget(self.title)
        titles.addWidget(self.sub)
        head.addWidget(self.toggle)
        head.addLayout(titles, 1)
        for text, tip, fn in (("↑", t("Move up"), lambda: self.move_requested.emit(self, -1)),
                              ("↓", t("Move down"), lambda: self.move_requested.emit(self, 1))):
            b = QToolButton()
            b.setText(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            head.addWidget(b)
        rm = QToolButton()
        rm.setText("✕")
        rm.setObjectName("Danger")
        rm.setToolTip(t("Remove this entry"))
        rm.clicked.connect(lambda: self.remove_requested.emit(self))
        head.addWidget(rm)
        outer.addLayout(head)

        # Body: two-column grid, "wide" fields span both columns
        self.body = QWidget()
        grid = QGridLayout(self.body)
        grid.setContentsMargins(0, 4, 0, 0)
        grid.setHorizontalSpacing(12)
        grid.setVerticalSpacing(10)
        self.fields: dict[str, Field] = {}
        row = col = 0
        for f in spec.fields:
            w = Field(f, lang)
            w.changed.connect(self._on_change)
            self.fields[f.key] = w
            if f.wide or f.kind == "text":
                if col:
                    row, col = row + 1, 0
                grid.addWidget(w, row, 0, 1, 2)
                row += 1
            else:
                grid.addWidget(w, row, col)
                col = (col + 1) % 2
                row += 1 if col == 0 else 0
        outer.addWidget(self.body)
        self.set_expanded(expanded)
        self._refresh_title()

    def _on_change(self) -> None:
        self._refresh_title()
        self.changed.emit()

    def _refresh_title(self) -> None:
        keys = self.spec.item_title_keys
        first = str(self.fields[keys[0]].value() or "").strip()
        self.title.setText(first or t("New entry"))
        sub = " / ".join(str(self.fields[k].value()).strip() for k in keys[1:]
                         if str(self.fields[k].value()).strip())
        dates = [str(self.fields[k].value()).strip() for k in ("start", "end") if k in self.fields]
        dates = [d for d in dates if d]
        if dates:
            sub = (sub + "   " if sub else "") + " - ".join(dates)
        self.sub.setText(sub)
        self.sub.setVisible(bool(sub))

    def set_expanded(self, on: bool) -> None:
        self.body.setVisible(on)
        self.toggle.setChecked(on)
        self.toggle.setText("▾" if on else "▸")
        self.setProperty("expanded", "true" if on else "false")
        self.style().unpolish(self)
        self.style().polish(self)

    def get(self) -> dict[str, Any]:
        return {k: f.value() for k, f in self.fields.items()}

    def set(self, item: dict[str, Any]) -> None:
        for k, f in self.fields.items():
            f.set_value(item.get(k, 0 if f.spec.kind == "level" else ""))
        self._refresh_title()

    def focus_first(self) -> None:
        first = next(iter(self.fields.values()))
        first.editor.setFocus()


class ListSection(QWidget):
    """Vertical stack of EntryCards + an add button."""

    changed = pyqtSignal()

    def __init__(self, spec: SectionSpec, lang: str | None = None, parent=None):
        super().__init__(parent)
        self.spec = spec
        self.lang = lang = lang or ui_lang()
        self.cards: list[EntryCard] = []
        self.lay = QVBoxLayout(self)
        self.lay.setContentsMargins(0, 0, 0, 0)
        self.lay.setSpacing(10)
        title = spec.title_bg if lang == "bg" else spec.title_en
        self.add_btn = QPushButton(("+ Добави: " if lang == "bg" else "+ Add to ") + title.lower())
        self.add_btn.setObjectName("Ghost")
        self.add_btn.setMinimumHeight(44)
        self.add_btn.clicked.connect(self._add_clicked)
        self.lay.addWidget(self.add_btn)

    def _make_card(self, item: dict[str, Any] | None, expanded: bool) -> EntryCard:
        card = EntryCard(self.spec, self.lang, expanded)
        if item:
            card.set(item)
        card.changed.connect(self.changed)
        card.remove_requested.connect(self._remove)
        card.move_requested.connect(self._move)
        self.cards.append(card)
        self.lay.insertWidget(self.lay.count() - 1, card)
        return card

    def _add_clicked(self) -> None:
        for c in self.cards:
            c.set_expanded(False)
        card = self._make_card(None, True)
        card.focus_first()
        self.changed.emit()

    def _remove(self, card: EntryCard) -> None:
        self.cards.remove(card)
        card.setParent(None)
        card.deleteLater()
        self.changed.emit()

    def _move(self, card: EntryCard, delta: int) -> None:
        i = self.cards.index(card)
        j = i + delta
        if not 0 <= j < len(self.cards):
            return
        self.cards[i], self.cards[j] = self.cards[j], self.cards[i]
        self.lay.removeWidget(card)
        self.lay.insertWidget(j, card)
        self.changed.emit()

    def get(self) -> list[dict[str, Any]]:
        return [c.get() for c in self.cards]

    def set(self, items: list[dict[str, Any]]) -> None:
        for c in list(self.cards):
            c.setParent(None)
            c.deleteLater()
        self.cards.clear()
        compact = len(items) > 2 or self.spec.key in ("skills", "languages")
        for item in items:
            self._make_card(item, expanded=not compact)


# --------------------------------------------------------------------------
# Toast notification
# --------------------------------------------------------------------------
class Toast(QLabel):
    """Short confirmation at the bottom of the window. Fades out by itself."""

    def __init__(self, parent: QWidget):
        super().__init__(parent)
        self.setStyleSheet("background:#eceef3; color:#1b202b; padding:10px 16px; border-radius:10px;"
                           "font-weight:700;")
        self.setSizePolicy(QSizePolicy.Policy.Fixed, QSizePolicy.Policy.Fixed)
        self._fx = QGraphicsOpacityEffect(self)
        self.setGraphicsEffect(self._fx)
        self._anim = QPropertyAnimation(self._fx, b"opacity", self)
        self._anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._anim.finished.connect(self._after_anim)
        self._timer = QTimer(self, singleShot=True, timeout=self._fade_out)
        self.hide()

    def show_message(self, text: str, ms: int = 2600, error: bool = False) -> None:
        self.setStyleSheet(
            f"background:{'#ff7a8a' if error else '#eceef3'}; color:#1b202b; padding:10px 16px;"
            "border-radius:10px; font-weight:700;")
        self.setText(text)
        self.adjustSize()
        p = self.parentWidget()
        self.move((p.width() - self.width()) // 2, p.height() - self.height() - 28)
        self.raise_()
        self.show()
        self._anim.stop()
        self._anim.setDuration(160)
        self._anim.setStartValue(0.0)
        self._anim.setEndValue(1.0)
        self._anim.start()
        self._timer.start(ms)

    def _fade_out(self) -> None:
        self._anim.stop()
        self._anim.setDuration(400)
        self._anim.setStartValue(1.0)
        self._anim.setEndValue(0.0)
        self._anim.start()

    def _after_anim(self) -> None:
        if self._fx.opacity() < 0.05:
            self.hide()


def page_header(title: str, hint: str = "") -> QWidget:
    w = QWidget()
    lay = QVBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 10)
    lay.setSpacing(4)
    heading = QLabel(title)
    heading.setObjectName("PageTitle")
    lay.addWidget(heading)
    if hint:
        h = QLabel(hint)
        h.setObjectName("PageHint")
        h.setWordWrap(True)
        lay.addWidget(h)
    return w
