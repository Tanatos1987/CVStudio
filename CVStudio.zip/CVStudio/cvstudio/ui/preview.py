"""
Live preview: the rendered HTML in a Chromium view.

The preview reloads a file on disk (see TemplateEngine.render_to_file).
Scroll position survives reloads, so typing in the Experience section does
not throw the view back to the top of page 1 on every keystroke.
"""
from __future__ import annotations

from pathlib import Path

from PyQt6.QtCore import Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QColor
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import QButtonGroup, QHBoxLayout, QLabel, QPushButton, QToolButton, QVBoxLayout, QWidget

from ..applog import log
from .i18n import t

A4_WIDTH_PX = 794  # 210 mm at 96 dpi


class PreviewPanel(QWidget):
    kind_changed = pyqtSignal(str)  # "cv" / "letter"

    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        bar = QWidget()
        bar.setObjectName("PreviewBar")
        b = QHBoxLayout(bar)
        b.setContentsMargins(14, 8, 10, 8)
        b.setSpacing(0)
        self.btn_cv = QPushButton("CV")
        self.btn_cv.setObjectName("SegLeft")
        self.btn_letter = QPushButton(t("Letter"))
        self.btn_letter.setObjectName("SegRight")
        group = QButtonGroup(self)
        for btn, kind in ((self.btn_cv, "cv"), (self.btn_letter, "letter")):
            btn.setCheckable(True)
            group.addButton(btn)
            btn.clicked.connect(lambda _, k=kind: self.kind_changed.emit(k))
            b.addWidget(btn)
        self.btn_cv.setChecked(True)
        b.addSpacing(14)
        self.pages = QLabel("")
        self.pages.setObjectName("Status")
        b.addWidget(self.pages)
        b.addStretch()
        self.zoom_label = QLabel(t("Fit"))
        self.zoom_label.setObjectName("Status")
        for text, tip, fn in (("−", t("Zoom out"), lambda: self._step(-0.1)),
                              (t("Fit"), t("Fit page width"), self._fit_on),
                              ("+", t("Zoom in"), lambda: self._step(0.1))):
            tb = QToolButton()
            tb.setText(text)
            tb.setToolTip(tip)
            tb.clicked.connect(fn)
            b.addWidget(tb)
        b.addSpacing(6)
        b.addWidget(self.zoom_label)
        lay.addWidget(bar)

        self.view = QWebEngineView()
        self.view.setContextMenuPolicy(Qt.ContextMenuPolicy.NoContextMenu)
        self.view.page().setBackgroundColor(QColor("#3a3f4b"))
        s = self.view.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
        s.setAttribute(QWebEngineSettings.WebAttribute.ShowScrollBars, True)
        self.view.loadFinished.connect(self._restore_scroll)
        # A crashed renderer leaves an empty grey area; log it and reload.
        self.view.page().renderProcessTerminated.connect(self._on_renderer_stopped)
        self._last_load_ok: bool | None = None
        lay.addWidget(self.view, 1)

        self._fit = True
        self._zoom = 1.0
        self._scroll_y = 0
        self._current: Path | None = None

    # public ------------------------------------------------------------
    def set_kind(self, kind: str) -> None:
        (self.btn_letter if kind == "letter" else self.btn_cv).setChecked(True)

    def show_file(self, path: Path, keep_scroll: bool = True) -> None:
        same_doc = keep_scroll and self._current == path

        def go(y):
            self._scroll_y = int(y or 0) if same_doc else 0
            self._current = path
            self.view.load(QUrl.fromLocalFile(str(path)))

        if same_doc:
            self.view.page().runJavaScript("window.scrollY", go)
        else:
            go(0)

    # internals ---------------------------------------------------------
    def _on_renderer_stopped(self, status, code) -> None:
        log(f"preview renderer stopped: status={getattr(status, 'name', status)} exit_code={code}")
        self.pages.setText(t("The preview engine stopped. Reloading..."))
        if self._current:
            QTimer.singleShot(800, lambda: self.view.load(QUrl.fromLocalFile(str(self._current))))

    def _restore_scroll(self, ok: bool) -> None:
        if ok != self._last_load_ok:  # log changes only, not every keystroke
            log(f"preview load {'ok' if ok else 'FAILED'}: {self._current}")
            self._last_load_ok = ok
        if not ok:
            self.pages.setText(t("The preview could not be displayed."))
            return
        self._apply_zoom()
        if self._scroll_y:
            self.view.page().runJavaScript(f"window.scrollTo(0, {self._scroll_y});")
        # Printed pages hold 273 mm of content each (see base.css flow pads).
        self.view.page().runJavaScript(
            "(() => { const t = document.querySelector('table.flow'); if (!t) return 0;"
            " const mm = t.offsetHeight / 3.7795 - 24; return Math.max(1, Math.ceil((mm - 0.5) / 273)); })()",
            lambda n: self.pages.setText((t("{n} pages", n=n) if n > 1 else t("{n} page", n=n)) if n else ""))

    def _apply_zoom(self) -> None:
        if self._fit:
            self._zoom = max(0.35, min(1.6, (self.view.width() - 36) / A4_WIDTH_PX))
            self.zoom_label.setText(t("Fit {pct}%", pct=round(self._zoom * 100)))
        else:
            self.zoom_label.setText(f"{round(self._zoom * 100)}%")
        self.view.setZoomFactor(self._zoom)

    def _step(self, delta: float) -> None:
        self._fit = False
        self._zoom = max(0.3, min(2.5, self._zoom + delta))
        self._apply_zoom()

    def _fit_on(self) -> None:
        self._fit = True
        self._apply_zoom()

    def resizeEvent(self, e):
        super().resizeEvent(e)
        if self._fit:
            self._apply_zoom()
