"""
Background work. Translation hits the network and can take several
seconds, so it runs on a QThread and reports progress back via signals.
"""
from __future__ import annotations

from typing import Any

from PyQt6.QtCore import QObject, Qt, QThread, pyqtSignal

from .. import cv_parser
from ..translator import TranslationError, translate_profile_data


class TranslateWorker(QObject):
    progress = pyqtSignal(int, int)
    finished = pyqtSignal(dict)
    failed = pyqtSignal(str)

    def __init__(self, data: dict[str, Any], src: str, tgt: str):
        super().__init__()
        self.data, self.src, self.tgt = data, src, tgt

    def run(self) -> None:
        try:
            result = translate_profile_data(self.data, self.src, self.tgt,
                                            progress=lambda a, b: self.progress.emit(a, b))
        except TranslationError as exc:
            self.failed.emit(str(exc))
        except Exception as exc:  # never let a worker crash the app silently
            self.failed.emit(f"Translation failed: {exc}")
        else:
            self.finished.emit(result)


class ImportWorker(QObject):
    """Reads an old CV off the UI thread (OCR takes a few seconds per page)."""

    finished = pyqtSignal(object)   # cv_parser.ParsedCV
    failed = pyqtSignal(object)     # cv_parser.ParseError or Exception

    def __init__(self, path: str):
        super().__init__()
        self.path = path

    def run(self) -> None:
        try:
            parsed = cv_parser.extract(self.path)
        except Exception as exc:
            self.failed.emit(exc)
        else:
            self.finished.emit(parsed)


def run_in_thread(worker: QObject, owner: QObject) -> QThread:
    """Standard QThread wiring. The caller keeps the returned thread alive."""
    thread = QThread(owner)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    # QThread.quit() is thread-safe; a direct connection stops the thread even
    # if the main event loop is already shutting down.
    worker.finished.connect(thread.quit, Qt.ConnectionType.DirectConnection)
    worker.failed.connect(thread.quit, Qt.ConnectionType.DirectConnection)
    thread.finished.connect(worker.deleteLater)
    thread.start()
    return thread
