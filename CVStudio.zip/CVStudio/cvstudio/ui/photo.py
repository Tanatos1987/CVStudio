"""
Profile photo: pick, crop, preview.

CropCanvas shows the whole image under a dimmed overlay with a square
window cut out of it (a circle guide inside the square shows how round
templates will clip it). Drag to move, scroll or use the slider to zoom.
The image always covers the window, so the output never has empty edges.

The result is a 720x720 JPEG. Templates decide the final shape (circle,
arch, rounded square) with CSS, so one crop serves every design.
"""
from __future__ import annotations

from PyQt6.QtCore import QBuffer, QByteArray, QIODevice, QPointF, QRectF, Qt, pyqtSignal
from PyQt6.QtGui import QColor, QImage, QPainter, QPainterPath, QPen, QPixmap
from PyQt6.QtWidgets import (QDialog, QFileDialog, QHBoxLayout, QLabel, QPushButton, QSlider,
                             QVBoxLayout, QWidget)

from . import theme
from .i18n import t

OUTPUT_PX = 720


def image_to_jpeg(img: QImage, quality: int = 90) -> bytes:
    data = QByteArray()
    buf = QBuffer(data)
    buf.open(QIODevice.OpenModeFlag.WriteOnly)
    img.save(buf, "JPG", quality)
    return bytes(data)


class CropCanvas(QWidget):
    changed = pyqtSignal()

    def __init__(self, image: QImage, parent=None):
        super().__init__(parent)
        self.image = image
        self.setMinimumSize(460, 460)
        self.setCursor(Qt.CursorShape.OpenHandCursor)
        self.zoom = 1.0          # 1.0 = image just covers the crop window
        self.offset = QPointF()  # image centre relative to window centre, in screen px
        self._drag: QPointF | None = None

    # geometry --------------------------------------------------------------
    def window_rect(self) -> QRectF:
        side = min(self.width(), self.height()) * 0.78
        return QRectF((self.width() - side) / 2, (self.height() - side) / 2, side, side)

    def _scale(self) -> float:
        side = self.window_rect().width()
        return side / min(self.image.width(), self.image.height()) * self.zoom

    def _clamp(self) -> None:
        win = self.window_rect()
        s = self._scale()
        half_w = (self.image.width() * s - win.width()) / 2
        half_h = (self.image.height() * s - win.height()) / 2
        self.offset.setX(max(-half_w, min(half_w, self.offset.x())))
        self.offset.setY(max(-half_h, min(half_h, self.offset.y())))

    def image_rect(self) -> QRectF:
        win = self.window_rect()
        s = self._scale()
        w, h = self.image.width() * s, self.image.height() * s
        c = win.center() + self.offset
        return QRectF(c.x() - w / 2, c.y() - h / 2, w, h)

    def set_zoom(self, z: float) -> None:
        self.zoom = max(1.0, min(4.0, z))
        self._clamp()
        self.update()
        self.changed.emit()

    # painting --------------------------------------------------------------
    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), QColor(theme.FIELD))
        p.drawImage(self.image_rect(), self.image)

        win = self.window_rect()
        shade = QPainterPath()
        shade.addRect(QRectF(self.rect()))
        hole = QPainterPath()
        hole.addRect(win)
        p.fillPath(shade.subtracted(hole), QColor(15, 18, 26, 190))

        p.setPen(QPen(QColor(theme.MARKER), 2))
        p.drawRect(win)
        p.setPen(QPen(QColor(255, 255, 255, 110), 1, Qt.PenStyle.DashLine))
        p.drawEllipse(win)
        # rule-of-thirds guides help place the eyes
        p.setPen(QPen(QColor(255, 255, 255, 45), 1))
        for i in (1, 2):
            x = win.left() + win.width() * i / 3
            y = win.top() + win.height() * i / 3
            p.drawLine(QPointF(x, win.top()), QPointF(x, win.bottom()))
            p.drawLine(QPointF(win.left(), y), QPointF(win.right(), y))

    # interaction -----------------------------------------------------------
    def mousePressEvent(self, e):
        self._drag = e.position()
        self.setCursor(Qt.CursorShape.ClosedHandCursor)

    def mouseMoveEvent(self, e):
        if self._drag is not None:
            self.offset += e.position() - self._drag
            self._drag = e.position()
            self._clamp()
            self.update()

    def mouseReleaseEvent(self, _):
        self._drag = None
        self.setCursor(Qt.CursorShape.OpenHandCursor)

    def wheelEvent(self, e):
        self.set_zoom(self.zoom * (1.1 if e.angleDelta().y() > 0 else 1 / 1.1))

    def resizeEvent(self, e):
        self._clamp()
        super().resizeEvent(e)

    # output ----------------------------------------------------------------
    def result(self) -> QImage:
        win, img_rect = self.window_rect(), self.image_rect()
        s = self._scale()
        src = QRectF((win.left() - img_rect.left()) / s, (win.top() - img_rect.top()) / s,
                     win.width() / s, win.height() / s)
        out = QImage(OUTPUT_PX, OUTPUT_PX, QImage.Format.Format_RGB32)
        out.fill(QColor("white"))
        p = QPainter(out)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        p.drawImage(QRectF(0, 0, OUTPUT_PX, OUTPUT_PX), self.image, src)
        p.end()
        return out


class PhotoCropDialog(QDialog):
    def __init__(self, image: QImage, parent=None):
        super().__init__(parent)
        self.setWindowTitle(t("Crop photo"))
        self.canvas = CropCanvas(image)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(18, 18, 18, 18)
        lay.setSpacing(12)
        hint = QLabel(t("Drag to position, scroll to zoom. Keep the eyes near the upper guide line."))
        hint.setWordWrap(True)
        hint.setObjectName("Muted")
        lay.addWidget(hint)
        lay.addWidget(self.canvas, 1)

        row = QHBoxLayout()
        row.addWidget(QLabel(t("Zoom")))
        self.slider = QSlider(Qt.Orientation.Horizontal)
        self.slider.setRange(100, 400)
        self.slider.valueChanged.connect(lambda v: self.canvas.set_zoom(v / 100))
        self.canvas.changed.connect(lambda: (self.slider.blockSignals(True),
                                             self.slider.setValue(int(self.canvas.zoom * 100)),
                                             self.slider.blockSignals(False)))
        row.addWidget(self.slider, 1)
        cancel = QPushButton(t("Cancel"))
        cancel.clicked.connect(self.reject)
        ok = QPushButton(t("Use photo"))
        ok.setObjectName("Primary")
        ok.clicked.connect(self.accept)
        row.addSpacing(16)
        row.addWidget(cancel)
        row.addWidget(ok)
        lay.addLayout(row)
        self.resize(560, 640)

    def jpeg(self) -> bytes:
        return image_to_jpeg(self.canvas.result())


class PhotoFrame(QWidget):
    """Round preview + actions. Emits ``photo_changed(cropped, original)``."""

    photo_changed = pyqtSignal(object, object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self._cropped: bytes | None = None
        self._original: bytes | None = None
        lay = QHBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(18)
        self.preview = QLabel()
        self.preview.setFixedSize(112, 112)
        lay.addWidget(self.preview)

        col = QVBoxLayout()
        col.setSpacing(8)
        title = QLabel(t("Profile photo"))
        title.setObjectName("CardTitle")
        col.addWidget(title)
        hint = QLabel(t("JPG or PNG. A plain background and soft daylight print best."))
        hint.setObjectName("Muted")
        hint.setWordWrap(True)
        col.addWidget(hint)
        btns = QHBoxLayout()
        self.upload = QPushButton(t("Upload photo"))
        self.upload.clicked.connect(self.pick)
        self.recrop = QPushButton(t("Crop again"))
        self.recrop.clicked.connect(self.crop_again)
        self.remove = QPushButton(t("Remove"))
        self.remove.clicked.connect(self.clear)
        for b in (self.upload, self.recrop, self.remove):
            btns.addWidget(b)
        btns.addStretch()
        col.addLayout(btns)
        lay.addLayout(col, 1)
        self._paint()

    def set_photo(self, cropped: bytes | None, original: bytes | None) -> None:
        self._cropped, self._original = cropped, original
        self._paint()

    def pick(self) -> None:
        path, _ = QFileDialog.getOpenFileName(self, t("Choose a photo"), "",
                                              t("Images") + " (*.jpg *.jpeg *.png *.webp *.bmp)")
        if not path:
            return
        with open(path, "rb") as fh:
            self.open_bytes(fh.read())

    def open_bytes(self, raw: bytes) -> None:
        img = QImage.fromData(raw)
        if img.isNull():
            return
        # Store a sane original (max 2000px) instead of a 20 MB phone photo.
        if max(img.width(), img.height()) > 2000:
            img = img.scaled(2000, 2000, Qt.AspectRatioMode.KeepAspectRatio,
                             Qt.TransformationMode.SmoothTransformation)
        dlg = PhotoCropDialog(img, self.window())
        if dlg.exec():
            self._original = image_to_jpeg(img, 92)
            self._cropped = dlg.jpeg()
            self._paint()
            self.photo_changed.emit(self._cropped, self._original)

    def crop_again(self) -> None:
        if self._original:
            self.open_bytes(self._original)

    def clear(self) -> None:
        self._cropped = self._original = None
        self._paint()
        self.photo_changed.emit(None, None)

    def _paint(self) -> None:
        size = 112
        canvas = QPixmap(size * 2, size * 2)  # 2x for crisp edges on HiDPI
        canvas.fill(Qt.GlobalColor.transparent)
        p = QPainter(canvas)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setRenderHint(QPainter.RenderHint.SmoothPixmapTransform)
        ring = QRectF(4, 4, size * 2 - 8, size * 2 - 8)
        clip = QPainterPath()
        clip.addEllipse(ring.adjusted(10, 10, -10, -10))
        if self._cropped:
            img = QImage.fromData(self._cropped)
            p.setClipPath(clip)
            p.drawImage(ring.adjusted(10, 10, -10, -10), img)
            p.setClipping(False)
        else:
            p.fillPath(clip, QColor(theme.FIELD))
            p.setPen(QColor(theme.FAINT))
            f = p.font()
            f.setPointSize(26)
            p.setFont(f)
            p.drawText(ring, Qt.AlignmentFlag.AlignCenter, "+")
        p.setPen(QPen(QColor(theme.MARKER if self._cropped else theme.LINE), 4))
        p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawEllipse(ring)
        p.end()
        canvas.setDevicePixelRatio(2)
        self.preview.setPixmap(canvas)
        self.recrop.setEnabled(bool(self._original))
        self.remove.setEnabled(bool(self._cropped))
