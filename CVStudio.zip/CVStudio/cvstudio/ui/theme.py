"""
Visual identity of the desktop app.

Concept: a drafting table at night. Slate-blue surfaces (not black), paper
white text, and one "marker yellow" used only for the primary action and
the active navigation item, the way you would highlight one line on a
printout. Focus rings use a cool blue so keyboard users always see where
they are. The CV itself, shown in the preview, is the brightest thing on
screen, which keeps attention on the document.

Everything is expressed as QSS so it can be tweaked without touching code.
"""
from __future__ import annotations

import ctypes
import sys

from PyQt6.QtGui import QColor, QFont, QFontDatabase, QPalette
from PyQt6.QtWidgets import QApplication, QWidget

from ..paths import cache_dir, fonts_dir

# --------------------------------------------------------------------------
# Tokens
# --------------------------------------------------------------------------
BASE = "#1b202b"       # window background
PANEL = "#222838"      # nav rail, cards
RAISED = "#2a3144"     # hovered / elevated
FIELD = "#171c26"      # inputs sit *below* the surface
LINE = "#343d52"
LINE_SOFT = "#2b3244"
TEXT = "#eceef3"
MUTED = "#98a1b4"
FAINT = "#6b7489"
MARKER = "#ffd34e"     # the one highlight colour
MARKER_INK = "#1b202b"
FOCUS = "#8fb0ff"
DANGER = "#ff7a8a"
SUCCESS = "#6fd6a8"

UI_FONT = "Manrope"         # family names as stored inside the font files
DISPLAY_FONT = "Unbounded"


def load_fonts() -> None:
    """Register bundled fonts with Qt. Missing files fall back to Segoe UI."""
    for name in ("Manrope.ttf", "Unbounded.ttf"):
        path = fonts_dir() / name
        if path.exists():
            QFontDatabase.addApplicationFont(str(path))


def _check_icon() -> str:
    """Write the checkbox tick as a tiny SVG and return a QSS-friendly path."""
    path = cache_dir("ui") / "check.svg"
    path.write_text(
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16">'
        f'<path d="M3.5 8.4 6.6 11.4 12.6 4.8" fill="none" stroke="{MARKER_INK}" '
        'stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>',
        encoding="utf-8")
    return path.as_posix()


def stylesheet() -> str:
    check = _check_icon()
    return f"""
* {{
    font-family: "{UI_FONT}", "Segoe UI", sans-serif;
    font-size: 10pt;
    color: {TEXT};
    outline: none;
}}
QMainWindow, QDialog {{ background: {BASE}; }}
QToolTip {{ background: {RAISED}; color: {TEXT}; border: 1px solid {LINE}; padding: 6px 8px;
            border-radius: 6px; }}

/* ---------- navigation rail ---------- */
#NavRail {{ background: {PANEL}; border: none; border-right: 1px solid {LINE_SOFT}; }}
#NavRail > QWidget, #NavRailInner {{ background: {PANEL}; }}
#Wordmark {{ font-family: "{DISPLAY_FONT}"; font-size: 15pt; font-weight: 800; color: {TEXT};
             letter-spacing: -0.5px; }}
#WordmarkSub {{ color: {FAINT}; font-size: 8.5pt; }}
#RailLabel {{ color: {FAINT}; font-size: 8.5pt; font-weight: 600; padding: 10px 4px 3px 4px; }}

QPushButton#NavButton {{
    text-align: left; padding: 8px 12px; border: none; border-radius: 9px;
    color: {MUTED}; font-weight: 600; background: transparent;
}}
QPushButton#NavButton:hover {{ background: {RAISED}; color: {TEXT}; }}
QPushButton#NavButton:checked {{ background: {MARKER}; color: {MARKER_INK}; }}
QPushButton#NavButton:focus {{ border: 1px solid {FOCUS}; }}

/* ---------- buttons ---------- */
QPushButton {{
    background: {RAISED}; border: 1px solid {LINE}; border-radius: 9px;
    padding: 8px 14px; font-weight: 600;
}}
QPushButton:hover {{ border-color: {MUTED}; }}
QPushButton:pressed {{ background: {LINE}; }}
QPushButton:focus {{ border-color: {FOCUS}; }}
QPushButton:disabled {{ color: {FAINT}; border-color: {LINE_SOFT}; }}

QPushButton#Primary {{ background: {MARKER}; color: {MARKER_INK}; border: none; font-weight: 800; }}
QPushButton#Primary:hover {{ background: #ffdc72; }}
QPushButton#Primary:focus {{ border: 2px solid {FOCUS}; }}

QPushButton#Ghost {{ background: transparent; border: 1px dashed {LINE}; color: {MUTED}; }}
QPushButton#Ghost:hover {{ color: {TEXT}; border-color: {MUTED}; }}

QPushButton#Translate {{
    background: {FIELD}; border: 1px solid {LINE}; padding: 10px 12px; font-weight: 800;
}}
QPushButton#Translate:hover {{ border-color: {MARKER}; color: {MARKER}; }}

QToolButton {{ background: transparent; border: none; border-radius: 7px; padding: 5px; color: {MUTED}; }}
QToolButton:hover {{ background: {RAISED}; color: {TEXT}; }}
QToolButton:checked {{ background: {RAISED}; color: {MARKER}; }}
QToolButton#Danger:hover {{ color: {DANGER}; }}

/* ---------- inputs ---------- */
QLineEdit, QPlainTextEdit, QTextEdit, QComboBox, QSpinBox {{
    background: {FIELD}; border: 1px solid {LINE_SOFT}; border-radius: 8px;
    padding: 7px 9px; selection-background-color: {MARKER}; selection-color: {MARKER_INK};
}}
QLineEdit:focus, QPlainTextEdit:focus, QTextEdit:focus, QComboBox:focus {{ border: 1px solid {FOCUS}; }}
QLineEdit[readOnly="true"] {{ color: {MUTED}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {PANEL}; border: 1px solid {LINE}; selection-background-color: {RAISED};
                               padding: 4px; }}

QLabel#FieldLabel {{ color: {MUTED}; font-size: 8.8pt; font-weight: 600; }}
QLabel#PageTitle {{ font-family: "{DISPLAY_FONT}"; font-size: 17pt; font-weight: 700; letter-spacing: -0.5px; }}
QLabel#PageHint {{ color: {MUTED}; }}
QLabel#Muted {{ color: {MUTED}; }}
QLabel#Status {{ color: {FAINT}; font-size: 8.8pt; }}

/* ---------- entry cards ---------- */
QFrame#EntryCard {{ background: {PANEL}; border: 1px solid {LINE_SOFT}; border-radius: 12px; }}
QFrame#EntryCard[expanded="true"] {{ border-color: {LINE}; }}
QLabel#CardTitle {{ font-weight: 700; font-size: 10.5pt; }}
QLabel#CardSub {{ color: {MUTED}; }}

/* ---------- template gallery ---------- */
QFrame#TemplateCard {{ background: {PANEL}; border: 2px solid {LINE_SOFT}; border-radius: 14px; }}
QFrame#TemplateCard:hover {{ border-color: {LINE}; }}
QFrame#TemplateCard[selected="true"] {{ border: 2px solid {MARKER}; }}
QLabel#TplName {{ font-weight: 800; font-size: 11pt; }}
QLabel#TplTag {{ color: {MUTED}; font-size: 9pt; }}

/* ---------- preview ---------- */
#PreviewBar {{ background: {PANEL}; border-bottom: 1px solid {LINE_SOFT}; }}
QPushButton#SegLeft {{ border-top-left-radius: 8px; border-bottom-left-radius: 8px; border-top-right-radius: 0;
                       border-bottom-right-radius: 0; padding: 6px 14px; background: {FIELD}; }}
QPushButton#SegRight {{ border-top-right-radius: 8px; border-bottom-right-radius: 8px; border-top-left-radius: 0;
                        border-bottom-left-radius: 0; padding: 6px 14px; background: {FIELD}; }}
QPushButton#SegLeft:checked, QPushButton#SegRight:checked {{ background: {TEXT}; color: {BASE}; border-color: {TEXT}; }}

/* ---------- misc ---------- */
QScrollArea {{ border: none; background: transparent; }}
QScrollArea > QWidget > QWidget {{ background: transparent; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {LINE}; border-radius: 4px; min-height: 30px; }}
QScrollBar::handle:vertical:hover {{ background: {FAINT}; }}
QScrollBar::add-line, QScrollBar::sub-line {{ height: 0; }}
QScrollBar:horizontal {{ height: 0; }}
QSplitter::handle {{ background: {LINE_SOFT}; }}
QSplitter::handle:hover {{ background: {MARKER}; }}

QSlider::groove:horizontal {{ height: 4px; background: {LINE}; border-radius: 2px; }}
QSlider::sub-page:horizontal {{ background: {MARKER}; border-radius: 2px; }}
QSlider::handle:horizontal {{ background: {TEXT}; width: 14px; height: 14px; margin: -5px 0; border-radius: 7px; }}

QProgressBar {{ background: {FIELD}; border: none; border-radius: 3px; height: 6px; text-align: center; }}
QProgressBar::chunk {{ background: {MARKER}; border-radius: 3px; }}

QMenu {{ background: {PANEL}; border: 1px solid {LINE}; padding: 6px; border-radius: 8px; }}
QMenu::item {{ padding: 7px 18px; border-radius: 6px; }}
QMenu::item:selected {{ background: {RAISED}; }}

QMessageBox QLabel {{ color: {TEXT}; }}
QCheckBox {{ spacing: 8px; }}
QCheckBox::indicator {{ width: 16px; height: 16px; border-radius: 4px; border: 1px solid {LINE};
                        background: {FIELD}; }}
QCheckBox::indicator:checked {{ background: {MARKER}; border-color: {MARKER}; image: url({check}); }}
"""


def apply(app: QApplication) -> None:
    load_fonts()
    app.setStyle("Fusion")  # the only native style that fully obeys QSS
    pal = app.palette()
    pal.setColor(QPalette.ColorRole.Window, QColor(BASE))
    pal.setColor(QPalette.ColorRole.Base, QColor(FIELD))
    pal.setColor(QPalette.ColorRole.Text, QColor(TEXT))
    pal.setColor(QPalette.ColorRole.WindowText, QColor(TEXT))
    pal.setColor(QPalette.ColorRole.Button, QColor(RAISED))
    pal.setColor(QPalette.ColorRole.ButtonText, QColor(TEXT))
    pal.setColor(QPalette.ColorRole.Highlight, QColor(MARKER))
    pal.setColor(QPalette.ColorRole.HighlightedText, QColor(MARKER_INK))
    pal.setColor(QPalette.ColorRole.PlaceholderText, QColor(FAINT))
    app.setPalette(pal)
    app.setFont(QFont(UI_FONT, 10))
    app.setStyleSheet(stylesheet())


def dark_title_bar(widget: QWidget) -> None:
    """Windows 10 (20H1+) / 11: ask DWM for a dark caption bar."""
    if not sys.platform.startswith("win"):
        return
    try:
        hwnd = int(widget.winId())
        value = ctypes.c_int(1)
        for attr in (20, 19):  # DWMWA_USE_IMMERSIVE_DARK_MODE (new id, then old id)
            if ctypes.windll.dwmapi.DwmSetWindowAttribute(
                    hwnd, attr, ctypes.byref(value), ctypes.sizeof(value)) == 0:
                break
        # Windows 11: tint the caption to match the window background.
        colour = ctypes.c_int(0x002B201B)  # COLORREF is 0x00BBGGRR for #1b202b
        ctypes.windll.dwmapi.DwmSetWindowAttribute(hwnd, 35, ctypes.byref(colour), ctypes.sizeof(colour))
    except Exception:
        pass
