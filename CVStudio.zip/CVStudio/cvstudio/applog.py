"""
Tiny file logger shared by the app. Writes to %APPDATA%\\CVStudio\\logs\\app.log
(the .exe has no console, so this is where runtime problems become visible).
The file is trimmed to the last ~2000 lines on start-up.
"""
from __future__ import annotations

from datetime import datetime

from .paths import user_data_dir

_PATH = user_data_dir() / "logs" / "app.log"
_PATH.parent.mkdir(parents=True, exist_ok=True)
try:
    lines = _PATH.read_text(encoding="utf-8", errors="replace").splitlines()[-2000:]
    _PATH.write_text("\n".join(lines) + ("\n" if lines else ""), encoding="utf-8")
except FileNotFoundError:
    pass


def log(message: str) -> None:
    try:
        with open(_PATH, "a", encoding="utf-8") as fh:
            fh.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {message}\n")
    except OSError:
        pass
