"""
Old CV import.

Goal: get the user's existing text on screen fast and pre-fill whatever can
be detected with high confidence. Perfect structuring of arbitrary CVs is
not realistic, so the import dialog always shows the raw text next to the
suggestions and the user copies anything the heuristics missed.

Supported: .pdf (PyMuPDF), .docx (python-docx), .txt / .md, and images
(.jpg / .png). Legacy .doc is binary and needs Word itself; the user gets a
clear message.

Scanned PDFs and photos of a CV have no text layer. They are read with OCR:
MuPDF (inside PyMuPDF) has the Tesseract engine built in and only needs the
language files, which ship with the app in assets/tessdata (Bulgarian +
English). Nothing has to be installed separately.

Extras:
* The largest image on page 1 of a PDF (or the first picture in a DOCX) is
  offered as the profile photo.
* Section headings are recognised in English and Bulgarian.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path

try:  # PyMuPDF >= 1.24 prefers "pymupdf", older builds only ship "fitz"
    import pymupdf as fitz  # type: ignore
except ImportError:  # pragma: no cover
    import fitz  # type: ignore


class ParseError(RuntimeError):
    """``key`` is an English message template the UI can translate."""

    def __init__(self, key: str, **kwargs):
        self.key, self.kwargs = key, kwargs
        super().__init__(key.format(**kwargs) if kwargs else key)


OCR_LANGUAGES = "bul+eng"
OCR_DPI = 300
OCR_MAX_PAGES = 4  # about 2-4 seconds per page


# Heading keywords per target section. Matching is done on the lower-cased,
# colon-stripped line, so "WORK EXPERIENCE:" and "Трудов опит" both hit.
HEADINGS: dict[str, tuple[str, ...]] = {
    "summary": ("summary", "profile", "about me", "about", "professional summary",
                "objective", "профил", "за мен", "резюме", "професионален профил", "обобщение"),
    "experience": ("experience", "work experience", "professional experience",
                   "employment", "employment history", "work history", "career",
                   "трудов опит", "професионален опит", "опит", "професионална история"),
    "education": ("education", "education and training", "academic background",
                  "образование", "образование и обучение", "обучение"),
    "skills": ("skills", "technical skills", "core skills", "key skills", "competencies",
               "умения", "компетенции", "технически умения", "ключови умения", "умения и компетенции"),
    "languages": ("languages", "language skills", "езици", "чужди езици", "езикови умения"),
    "certifications": ("certifications", "certificates", "courses", "licenses",
                       "сертификати", "курсове", "квалификации"),
}

EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
PHONE_RE = re.compile(r"(?:\+?\d{1,3}[\s-]?)?(?:\(?\d{2,4}\)?[\s-]?)\d{3}[\s-]?\d{3,4}")
LINKEDIN_RE = re.compile(r"(?:https?://)?(?:[a-z]{2,3}\.)?linkedin\.com/in/[\w\-%]+/?", re.I)
GITHUB_RE = re.compile(r"(?:https?://)?github\.com/[\w\-]+/?", re.I)
URL_RE = re.compile(r"(?:https?://)?(?:www\.)?[a-z0-9\-]+\.(?:com|bg|eu|net|org|io|dev|me)(?:/\S*)?", re.I)
# "03/2019 - 05/2022", "2019 - Present", "Март 2018 - Настояще" (any dash)
DATE_RANGE_RE = re.compile(
    r"((?:[A-Za-zА-Яа-я]{3,10}\.?\s)?(?:\d{1,2}[./])?\d{4})\s*(?:-|\u2013|\u2014|to|до)\s*"
    r"((?:[A-Za-zА-Яа-я]{3,10}\.?\s)?(?:\d{1,2}[./])?\d{4}|present|current|now|настояще|досега|сега)",
    re.I,
)
BULLET_START_RE = re.compile(r"^\s*[•●▪◦‣∙·*\-\u2013\u2014]\s*")


@dataclass
class ParsedCV:
    source: Path
    text: str
    personal: dict[str, str] = field(default_factory=dict)
    sections: dict[str, str] = field(default_factory=dict)
    photo: bytes | None = None
    ocr: bool = False  # True when the text was recognised from an image


# --------------------------------------------------------------------------
# Raw extraction
# --------------------------------------------------------------------------
def _tessdata() -> Path:
    from .paths import resource_root
    return resource_root() / "assets" / "tessdata"


def _line_segments(page, textpage=None) -> list[tuple[float, float, float, float, str]]:
    """
    Words regrouped into line segments. A printed line that crosses a column
    gap (OCR often merges "Experience ... Skills" into one line) is split
    wherever the space between two words is wider than 4% of the page.
    Returns (x0, y0, x1, y1, text) per segment.
    """
    words = page.get_text("words", textpage=textpage)
    gap = page.rect.width * 0.04
    lines: dict[tuple[int, int], list] = {}
    for w in words:
        lines.setdefault((w[5], w[6]), []).append(w)
    segments = []
    for ws in lines.values():
        ws.sort(key=lambda w: w[0])
        current = [ws[0]]
        for w in ws[1:]:
            if w[0] - current[-1][2] > gap:
                segments.append(current)
                current = [w]
            else:
                current.append(w)
        segments.append(current)
    return [(min(w[0] for w in seg), min(w[1] for w in seg), max(w[2] for w in seg),
             max(w[3] for w in seg), " ".join(w[4] for w in seg)) for seg in segments]


def _column_text(page, textpage=None) -> str:
    """
    Reading order for two-column layouts: full-width lines above the columns,
    then the left column top to bottom, then the right column.
    """
    segs = _line_segments(page, textpage)
    if not segs:
        return ""
    width = page.rect.width
    # Where does the right column start? The most common start position
    # (in 2% bins) among segments beginning right of 40% of the page width.
    bins: dict[int, int] = {}
    for s in segs:
        if s[0] > width * 0.40:
            bins[int(s[0] / width * 50)] = bins.get(int(s[0] / width * 50), 0) + 1
    split = None
    if bins:
        best_bin, count = max(bins.items(), key=lambda kv: kv[1])
        if count >= 3:
            split = best_bin / 50 * width - width * 0.01
    by_y = lambda s: (round(s[1] / 4), s[0])  # noqa: E731  same row within ~4pt
    if split is None:
        return "\n".join(s[4] for s in sorted(segs, key=by_y))
    left = [s for s in segs if s[0] < split and s[2] <= split + width * 0.03]
    right = [s for s in segs if s[0] >= split]
    full = [s for s in segs if s not in left and s not in right]
    col_top = min((s[1] for s in left + right), default=0)
    head = [s for s in full if s[1] <= col_top + 2]
    rest = [s for s in full if s not in head]
    # full-width lines below the column tops (e.g. a summary spanning both
    # columns) read before the columns too, in vertical order
    ordered = sorted(head + rest, key=by_y) + sorted(left, key=by_y) + sorted(right, key=by_y)
    return "\n".join(s[4] for s in ordered)


def _name_by_size(page, textpage=None) -> str | None:
    """
    The name is usually the biggest text in the top half of page 1. Designs
    that stack first and last name on two lines are handled by joining all
    lines of (nearly) the biggest size.
    """
    cands = []
    for x0, y0, x1, y1, text in _line_segments(page, textpage):
        words = text.split()
        if y0 > page.rect.height * 0.45 or not 1 <= len(words) <= 4:
            continue
        if re.search(r"[\d@/:,|]", text) or _heading_key(text) or len(text) < 2:
            continue
        if not all(w[:1].isupper() for w in words):
            continue
        cands.append((y1 - y0, y0, text.strip()))
    if not cands:
        return None
    top = max(c[0] for c in cands)
    big = sorted((c for c in cands if c[0] >= top * 0.85), key=lambda c: c[1])
    name = " ".join(c[2] for c in big)
    return name if 2 <= len(name.split()) <= 4 else None


def _page_readings(page, textpage=None) -> list[str]:
    """Three reading orders of one page; extract() keeps the best one."""
    return [
        page.get_text("text", textpage=textpage),              # content-stream order
        _column_text(page, textpage),                          # column-aware
        page.get_text("text", sort=True, textpage=textpage),   # plain top-to-bottom
    ]


_JUNK_LINE = re.compile(r"^\W{0,2}\w?\W{0,2}$")  # OCR noise from icons: "©", "&", "fin)"


def _clean_ocr(text: str) -> str:
    return "\n".join(l for l in text.split("\n") if not _JUNK_LINE.fullmatch(l.strip()) or not l.strip())


def _pick_photo(doc) -> bytes | None:
    """Largest portrait-like image on page 1 that is not a full-page scan."""
    if not len(doc):
        return None
    page = doc[0]
    page_area = page.rect.width * page.rect.height
    best = (0, None)
    for img in page.get_images(full=True):
        xref = img[0]
        try:
            info = doc.extract_image(xref)
            rects = page.get_image_rects(xref)
        except Exception:
            continue
        w, h = info.get("width", 0), info.get("height", 0)
        shown = max((r.width * r.height for r in rects), default=0)
        if shown > page_area * 0.35:  # the scanned page itself, not a photo
            continue
        if w >= 120 and h >= 120 and 0.5 <= w / max(h, 1) <= 1.6 and w * h > best[0]:
            best = (w * h, info.get("image"))
    return best[1]


def _extract_pdf(path: Path) -> tuple[list[str], bytes | None, bool, str | None]:
    try:
        doc = fitz.open(str(path))
    except Exception as exc:
        raise ParseError("The PDF could not be opened: {error}", error=exc) from exc
    return _read_document(doc)


def _extract_image(path: Path) -> tuple[list[str], bytes | None, bool, str | None]:
    """A photo or screenshot of a CV: wrap it in a one-page PDF and OCR it."""
    try:
        img = fitz.open(str(path))
        doc = fitz.open("pdf", img.convert_to_pdf())
    except Exception as exc:
        raise ParseError("The image could not be opened: {error}", error=exc) from exc
    readings, _, _, name = _read_document(doc, force_ocr=True)
    return readings, None, True, name


def _read_document(doc, force_ocr: bool = False) -> tuple[list[str], bytes | None, bool, str | None]:
    pages = list(doc)
    has_text = sum(len(p.get_text("text").strip()) for p in pages) >= 40
    ocr = force_ocr or not has_text
    per_page: list[list[str]] = []
    name = None
    if not ocr:
        per_page = [_page_readings(p) for p in pages]
        name = _name_by_size(pages[0]) if pages else None
    else:
        tessdata = _tessdata()
        if not (tessdata / "bul.traineddata").exists():
            raise ParseError("Text recognition (OCR) files are missing. Run install_and_run.bat rebuild.")
        for p in pages[:OCR_MAX_PAGES]:
            try:
                tp = p.get_textpage_ocr(language=OCR_LANGUAGES, dpi=OCR_DPI, full=True,
                                        tessdata=str(tessdata))
            except Exception as exc:
                raise ParseError("Text recognition (OCR) failed: {error}", error=exc) from exc
            per_page.append([_clean_ocr(r) for r in _page_readings(p, tp)])
            if name is None:
                name = _name_by_size(p, tp)
    readings = ["\n".join(page[i] for page in per_page).strip() for i in range(3)]
    if ocr:  # OCR output has no meaningful stream order; prefer the column reading
        readings = [readings[1], readings[0], readings[2]]
    if not any(readings):
        raise ParseError("No text could be read from this file, not even with OCR. Use a sharper "
                         "scan, or a PDF exported directly from Word or the CV website.")
    photo = _pick_photo(doc)
    doc.close()
    return readings, photo, ocr, name


def _extract_docx(path: Path) -> tuple[str, bytes | None]:
    try:
        import docx  # python-docx
    except ImportError as exc:  # pragma: no cover
        raise ParseError("python-docx is not installed.") from exc
    try:
        document = docx.Document(str(path))
    except Exception as exc:
        raise ParseError("The Word file could not be opened: {error}", error=exc) from exc

    lines: list[str] = [p.text for p in document.paragraphs]
    # Many CV templates are built from tables; read them cell by cell.
    for table in document.tables:
        for row in table.rows:
            seen: set[int] = set()
            for cell in row.cells:
                if id(cell._tc) in seen:  # merged cells repeat
                    continue
                seen.add(id(cell._tc))
                lines.extend(p.text for p in cell.paragraphs)

    photo = None
    for rel in document.part.rels.values():
        if "image" in rel.reltype:
            try:
                blob = rel.target_part.blob
            except Exception:
                continue
            if len(blob) > 8_000:  # skip tiny icons
                photo = blob
                break
    return "\n".join(lines).strip(), photo


IMAGE_TYPES = (".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff", ".webp")


def extract(path: str | Path) -> ParsedCV:
    path = Path(path)
    suffix = path.suffix.lower()
    ocr = False
    name_hint = None
    if suffix == ".pdf":
        readings, photo, ocr, name_hint = _extract_pdf(path)
    elif suffix in IMAGE_TYPES:
        readings, photo, ocr, name_hint = _extract_image(path)
    elif suffix == ".docx":
        text, photo = _extract_docx(path)
        readings = [text]
    elif suffix in (".txt", ".md"):
        readings, photo = [path.read_text(encoding="utf-8", errors="replace")], None
    elif suffix == ".doc":
        raise ParseError(
            "Old .doc files are not supported. Open the file in Word and use "
            "File > Save As > Word Document (.docx), then import that file."
        )
    else:
        raise ParseError("Unsupported file type: {ext}", ext=suffix)

    def tidy(t: str) -> str:
        t = re.sub(r"[ \t]+\n", "\n", t)
        # "04/2021" + newline + "- Present" (a date range broken over two lines)
        t = re.sub(r"(\d{4})[ \t]*\n[ \t]*(-|\u2013|\u2014)[ \t]*", r"\1 - ", t)
        return re.sub(r"\n{3,}", "\n\n", t).strip()

    # Keep the reading order in which the most section headings are found;
    # on a tie the earlier (preferred) reading wins.
    candidates = [tidy(r) for r in readings if r and r.strip()]
    text = max(candidates, key=lambda c: len(_split_sections(c))) if candidates else ""
    parsed = ParsedCV(source=path, text=text, photo=photo, ocr=ocr)
    parsed.personal = _detect_personal(text)
    if name_hint:
        parsed.personal["full_name"] = " ".join(w.capitalize() if w.isupper() else w for w in name_hint.split())
    parsed.sections = _split_sections(text)
    return parsed


# --------------------------------------------------------------------------
# Heuristics
# --------------------------------------------------------------------------
def _detect_personal(text: str) -> dict[str, str]:
    found: dict[str, str] = {}
    if m := EMAIL_RE.search(text):
        found["email"] = m.group(0)
    if m := LINKEDIN_RE.search(text):
        found["linkedin"] = m.group(0).rstrip("/")
    if m := GITHUB_RE.search(text):
        found["github"] = m.group(0).rstrip("/")
    for m in PHONE_RE.finditer(text):
        digits = re.sub(r"\D", "", m.group(0))
        if 9 <= len(digits) <= 13 and not re.fullmatch(r"(19|20)\d{2}(19|20)\d{2}", digits):
            found["phone"] = m.group(0).strip()
            break
    for m in URL_RE.finditer(text):
        url = m.group(0)
        if "linkedin" in url.lower() or "github" in url.lower() or "@" in url:
            continue
        if "email" in found and url in found["email"]:
            continue
        found["website"] = url
        break

    # Name: the first short line near the top made of 2-4 capitalised words.
    for line in text.split("\n")[:8]:
        clean = line.strip()
        words = clean.split()
        if 2 <= len(words) <= 4 and not re.search(r"[\d@/:,|]", clean) \
                and all(w[:1].isupper() for w in words) and len(clean) < 45 \
                and _heading_key(clean) is None:
            found["full_name"] = " ".join(w.capitalize() if w.isupper() else w for w in words)
            break
    return found


def _heading_key(line: str) -> str | None:
    norm = re.sub(r"[:\s]+$", "", line.strip().lower())
    norm = re.sub(r"\s+", " ", norm)
    if not norm or len(norm) > 40:
        return None
    for key, words in HEADINGS.items():
        if norm in words:
            return key
    return None


def _split_sections(text: str) -> dict[str, str]:
    sections: dict[str, list[str]] = {}
    current: str | None = None
    for line in text.split("\n"):
        key = _heading_key(line)
        if key:
            current = key
            sections.setdefault(key, [])
            continue
        if current:
            sections[current].append(line)
    return {k: "\n".join(v).strip() for k, v in sections.items() if "\n".join(v).strip()}


def guess_list(section_text: str) -> list[str]:
    """Skills / languages: split on commas, bullets, pipes and newlines."""
    raw = re.split(r"[,\n|;•●▪]", section_text)
    items = [BULLET_START_RE.sub("", r).strip(" .\t") for r in raw]
    return [i for i in items if 1 < len(i) < 60]


_LEVEL_RE = re.compile(
    r"^(?:[ABC][12]\b|native|mother tongue|fluent|proficient|basic|elementary|intermediate|"
    r"advanced|upper|роден|майчин|свободно|отлично|добро|основно|средно|напреднало|начално)", re.I)


def guess_languages(section_text: str) -> list[dict[str, str]]:
    """'English - C1' or 'English' + 'C1' on separate lines -> {name, level}."""
    out: list[dict[str, str]] = []
    for item in guess_list(section_text):
        parts = re.split(r"\s*[-:(\u2013\u2014]\s*", item, maxsplit=1)
        if _LEVEL_RE.match(item) and out and not out[-1]["level"]:
            out[-1]["level"] = item.strip(" )")
        elif len(parts) > 1:
            out.append({"name": parts[0].strip(), "level": parts[1].strip(" )")})
        else:
            out.append({"name": item.strip(), "level": ""})
    return out


def guess_entries(section_text: str) -> list[dict[str, str]]:
    """
    Experience / education: blocks separated by blank lines or by lines with
    a date range. First non-bullet line -> title, second -> organisation,
    bullet lines -> description.
    """
    blocks: list[list[str]] = []
    current: list[str] = []
    for line in section_text.split("\n"):
        starts_new = bool(DATE_RANGE_RE.search(line)) and current and \
            any(DATE_RANGE_RE.search(l) for l in current)
        if starts_new:
            # The job title usually sits on the line just above its dates,
            # so carry that line over into the new block.
            carry = [current.pop()] if len(current) > 1 and not BULLET_START_RE.match(current[-1]) else []
            blocks.append(current)
            current = carry + [line]
        elif not line.strip():
            if current:
                blocks.append(current)
            current = []
        else:
            current.append(line)
    if current:
        blocks.append(current)

    entries: list[dict[str, str]] = []
    for block in blocks:
        start = end = ""
        heads: list[str] = []
        bullets: list[str] = []
        for line in block:
            m = DATE_RANGE_RE.search(line)
            if m and not start:
                start, end = m.group(1).strip(), m.group(2).strip()
                line = (line[:m.start()] + line[m.end():]).strip(" ,|-\u2013")
            if not line.strip():
                continue
            if BULLET_START_RE.match(line) or len(heads) >= 2:
                bullets.append("• " + BULLET_START_RE.sub("", line).strip())
            else:
                heads.append(line.strip())
        if not heads and not bullets:
            continue
        entries.append({
            "a": heads[0] if heads else "",
            "b": heads[1] if len(heads) > 1 else "",
            "start": start,
            "end": end,
            "description": "\n".join(bullets),
        })
    return entries
