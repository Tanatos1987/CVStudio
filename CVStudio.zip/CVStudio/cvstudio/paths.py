"""
Path helpers.

Two worlds have to be handled here:

* Running from source: bundled resources (templates, fonts) live next to
  this package.
* Running as a PyInstaller --onefile .exe: the bundle is unpacked into a
  temporary folder exposed as ``sys._MEIPASS``. That folder is read-only in
  spirit and deleted on exit, so anything the user creates (the SQLite
  database, rendered previews, thumbnails) must go to a per-user data folder
  instead: %APPDATA%\\CVStudio on Windows, ~/.cvstudio elsewhere.
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

APP_NAME = "CVStudio"


def resource_root() -> Path:
    """Folder that contains the read-only ``templates`` and ``assets`` dirs."""
    if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
        return Path(sys._MEIPASS)  # type: ignore[attr-defined]
    return Path(__file__).resolve().parent


def templates_dir() -> Path:
    return resource_root() / "templates"


def fonts_dir() -> Path:
    return resource_root() / "assets" / "fonts"


def user_data_dir() -> Path:
    """Writable per-user folder. Created on first access."""
    if sys.platform.startswith("win"):
        base = Path(os.environ.get("APPDATA", Path.home() / "AppData" / "Roaming"))
        root = base / APP_NAME
    else:
        root = Path.home() / f".{APP_NAME.lower()}"
    root.mkdir(parents=True, exist_ok=True)
    return root


def database_path() -> Path:
    return user_data_dir() / "profiles.sqlite3"


def cache_dir(name: str) -> Path:
    """Sub-folder of the data dir for regenerable files (previews, thumbs)."""
    p = user_data_dir() / "cache" / name
    p.mkdir(parents=True, exist_ok=True)
    return p


def as_file_url(path: Path) -> str:
    """file:/// URL usable from HTML, with forward slashes on Windows."""
    return path.resolve().as_uri()
