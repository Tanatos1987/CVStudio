"""CV Studio - desktop CV and cover letter builder."""
__version__ = "1.0.3"
