"""
Bulgarian <-> English translation that keeps CV structure intact.

The naive approach (send the whole Experience description to Google) breaks
things: bullet glyphs get dropped or turned into dashes, numbered lists get
renumbered, blank lines between paragraphs vanish. So every multi-line field
is taken apart first:

    "• Cut food cost from 31% to 26%"   ->  prefix "• "   body "Cut food cost ..."

Only the bodies travel to the translation service. They are de-duplicated,
packed into as few requests as possible (newline-joined, under the 5000
character limit) and put back behind their original prefixes afterwards.

Three other field kinds get special handling (see ``models.FieldSpec``):

* "name"  - people and company names are transliterated with the official
            Bulgarian Streamlined System (Тодор Николов -> Todor Nikolov)
            instead of being "translated" (Топола -> Poplar).
* "date"  - month names and "Present" / "Настояще" are swapped from a
            dictionary; digits are left alone.
* None    - emails, phones, URLs, years: never touched.

The module is Qt-free so it can be unit tested and reused from scripts.
"""
from __future__ import annotations

import copy
import re
from typing import Any, Callable, Iterable

from .models import LETTER_FIELDS, PERSONAL_FIELDS, SECTIONS

# Bullet / numbering prefixes that must survive translation untouched.
BULLET_RE = re.compile(r"^(\s*(?:[•●▪◦‣∙·*\-\u2013]|\d{1,2}[.)])\s+)(.*)$")
HAS_LETTER_RE = re.compile(r"[A-Za-zА-Яа-яЁё]")
CYRILLIC_RE = re.compile(r"[А-Яа-я]")

MAX_CHARS_PER_REQUEST = 4500  # Google web endpoint limit is 5000

ProgressFn = Callable[[int, int], None]


class TranslationError(RuntimeError):
    """Raised with a message that can be shown to the user as-is."""


# --------------------------------------------------------------------------
# Transliteration (Bulgarian Streamlined System, 2009 law)
# --------------------------------------------------------------------------
_TRANSLIT = {
    "а": "a", "б": "b", "в": "v", "г": "g", "д": "d", "е": "e", "ж": "zh",
    "з": "z", "и": "i", "й": "y", "к": "k", "л": "l", "м": "m", "н": "n",
    "о": "o", "п": "p", "р": "r", "с": "s", "т": "t", "у": "u", "ф": "f",
    "х": "h", "ц": "ts", "ч": "ch", "ш": "sh", "щ": "sht", "ъ": "a", "ь": "y",
    "ю": "yu", "я": "ya",
}


# Names the law itself lists as exceptions to the letter-by-letter rules.
_TRANSLIT_EXCEPTIONS = {"България": "Bulgaria", "БЪЛГАРИЯ": "BULGARIA", "София": "Sofia"}


def transliterate_bg(text: str) -> str:
    """Cyrillic -> Latin. Keeps capitalisation: 'Жечев' -> 'Zhechev'."""
    for bg, en in _TRANSLIT_EXCEPTIONS.items():
        text = re.sub(rf"\b{bg}\b", en, text)
    # Rule of the law: "-ия" at the end of a word becomes "-ia" (България -> Bulgaria)
    text = re.sub(r"ия\b", "ia", text)
    text = re.sub(r"ИЯ\b", "IA", text)
    out: list[str] = []
    for i, ch in enumerate(text):
        low = ch.lower()
        if low not in _TRANSLIT:
            out.append(ch)
            continue
        lat = _TRANSLIT[low]
        if ch.isupper():
            nxt = text[i + 1] if i + 1 < len(text) else ""
            # ALL-CAPS word -> ALL-CAPS output, otherwise Title case
            lat = lat.upper() if nxt.isupper() else lat.capitalize()
        out.append(lat)
    return "".join(out)


# --------------------------------------------------------------------------
# Dates
# --------------------------------------------------------------------------
_MONTHS_EN = ["January", "February", "March", "April", "May", "June", "July",
              "August", "September", "October", "November", "December"]
_MONTHS_BG = ["Януари", "Февруари", "Март", "Април", "Май", "Юни", "Юли",
              "Август", "Септември", "Октомври", "Ноември", "Декември"]
_DATE_WORDS_BG_EN = {"настояще": "Present", "досега": "Present", "сега": "Present",
                     "понастоящем": "Present"}
_DATE_WORDS_EN_BG = {"present": "Настояще", "current": "Настояще", "now": "Настояще",
                     "today": "Настояще"}


def translate_date(text: str, src: str, tgt: str) -> str:
    if not text or src == tgt:
        return text
    if src == "bg":
        pairs = list(zip(_MONTHS_BG, _MONTHS_EN)) + \
                [(m[:3], e[:3]) for m, e in zip(_MONTHS_BG, _MONTHS_EN)]
        words = _DATE_WORDS_BG_EN
    else:
        pairs = list(zip(_MONTHS_EN, _MONTHS_BG)) + \
                [(e[:3], b[:3]) for e, b in zip(_MONTHS_EN, _MONTHS_BG)]
        words = _DATE_WORDS_EN_BG

    def swap(match: re.Match) -> str:
        word = match.group(0)
        if word.lower() in words:
            return words[word.lower()]
        for a, b in pairs:
            if word.lower() == a.lower():
                return b
        return word

    return re.sub(r"[A-Za-zА-Яа-я]+", swap, text)


# --------------------------------------------------------------------------
# Structure-aware splitting
# --------------------------------------------------------------------------
def split_lines(text: str) -> list[tuple[str, str]]:
    """'• a\\n\\nb' -> [('• ', 'a'), ('', ''), ('', 'b')]"""
    parts: list[tuple[str, str]] = []
    for line in text.split("\n"):
        m = BULLET_RE.match(line)
        parts.append((m.group(1), m.group(2)) if m else ("", line))
    return parts


def join_lines(parts: Iterable[tuple[str, str]]) -> str:
    return "\n".join(prefix + body for prefix, body in parts)


# --------------------------------------------------------------------------
# Translation backend
# --------------------------------------------------------------------------
class Translator:
    """Thin, cached wrapper around deep-translator's GoogleTranslator."""

    def __init__(self, src: str, tgt: str):
        self.src, self.tgt = src, tgt
        self._cache: dict[str, str] = {}
        try:
            from deep_translator import GoogleTranslator
        except ImportError as exc:  # pragma: no cover
            raise TranslationError("The 'deep-translator' package is missing.") from exc
        self._engine = GoogleTranslator(source=src, target=tgt)

    def _call(self, text: str) -> str:
        try:
            result = self._engine.translate(text)
        except Exception as exc:  # deep-translator raises many exception types
            raise TranslationError(
                "Translation service unreachable. Check the internet connection "
                f"and try again. ({exc.__class__.__name__})"
            ) from exc
        return result if isinstance(result, str) else text

    def translate_many(self, segments: list[str], progress: ProgressFn | None = None) -> list[str]:
        """Translate a list of single-line strings with as few requests as possible."""
        todo = [s for s in dict.fromkeys(segments) if s not in self._cache]

        # Pack segments into newline-joined chunks below the size limit.
        chunks: list[list[str]] = []
        current: list[str] = []
        size = 0
        for seg in todo:
            if current and size + len(seg) + 1 > MAX_CHARS_PER_REQUEST:
                chunks.append(current)
                current, size = [], 0
            current.append(seg)
            size += len(seg) + 1
        if current:
            chunks.append(current)

        for n, chunk in enumerate(chunks, start=1):
            joined = self._call("\n".join(chunk))
            pieces = [p.strip() for p in joined.split("\n")]
            if len(pieces) != len(chunk):
                # The service merged or split lines. Fall back to one request
                # per segment for this chunk so alignment is guaranteed.
                pieces = [self._call(seg).strip() for seg in chunk]
            self._cache.update(zip(chunk, pieces))
            if progress:
                progress(n, len(chunks))

        return [self._cache.get(s, s) for s in segments]


# --------------------------------------------------------------------------
# Whole-profile translation
# --------------------------------------------------------------------------
def translate_profile_data(data: dict[str, Any], src: str, tgt: str,
                           progress: ProgressFn | None = None,
                           translator: Translator | None = None) -> dict[str, Any]:
    """Return a translated deep copy of ``data``. ``data`` itself is not modified."""
    if src == tgt:
        return copy.deepcopy(data)
    out = copy.deepcopy(data)
    tr = translator or Translator(src, tgt)

    # Each slot remembers where a text body lives: (container, key, line_index)
    # line_index is None for single-line fields.
    slots: list[tuple[dict, str, int | None]] = []
    split_cache: dict[tuple[int, str], list[tuple[str, str]]] = {}
    segments: list[str] = []

    def handle(container: dict, spec) -> None:
        value = container.get(spec.key)
        if not isinstance(value, str) or not value.strip():
            return
        if spec.translate == "date":
            container[spec.key] = translate_date(value, src, tgt)
        elif spec.translate == "name":
            if src == "bg" and CYRILLIC_RE.search(value):
                container[spec.key] = transliterate_bg(value)
            # EN -> BG: names stay Latin, the user edits them if wanted.
        elif spec.translate == "text":
            if spec.kind == "text":
                parts = split_lines(value)
                split_cache[(id(container), spec.key)] = parts
                for i, (_, body) in enumerate(parts):
                    if HAS_LETTER_RE.search(body):
                        slots.append((container, spec.key, i))
                        segments.append(body.strip())
            elif HAS_LETTER_RE.search(value):
                slots.append((container, spec.key, None))
                segments.append(value.strip())

    for spec in PERSONAL_FIELDS:
        handle(out["personal"], spec)
    for spec in LETTER_FIELDS:
        handle(out["cover_letter"], spec)
    for section in SECTIONS:
        for item in out.get(section.key, []):
            for spec in section.fields:
                handle(item, spec)

    if not segments:
        return out

    translated = tr.translate_many(segments, progress)

    # Put translated bodies back behind their original prefixes.
    for (container, key, line_idx), text in zip(slots, translated):
        if line_idx is None:
            container[key] = text
        else:
            parts = split_cache[(id(container), key)]
            prefix, _ = parts[line_idx]
            parts[line_idx] = (prefix, text)
    for (container, key, line_idx) in slots:
        if line_idx is not None:
            container[key] = join_lines(split_cache[(id(container), key)])
    return out
