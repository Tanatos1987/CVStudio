"""
HTML -> PDF.

Engine choice
-------------
WeasyPrint was the first candidate, but on Windows it needs the GTK/Pango
runtime (a separate MSYS2 install). Those DLLs cannot be reliably packed into
a single PyInstaller .exe, which breaks the "double-click and it works" goal.

The live preview already runs Chromium through QtWebEngine, and Chromium's
print engine is excellent: full flexbox/grid, variable fonts, clip-path,
gradients, repeated backgrounds on every page. Printing with the same engine
that draws the preview also guarantees the PDF looks exactly like the
preview. So Chromium is the default.

WeasyPrint stays available as an optional backend for Linux/macOS users or
anyone who has GTK installed: ``pip install weasyprint`` and pick it in the
export menu. If the import fails the option is simply hidden.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from PyQt6.QtCore import QMarginsF, QObject, Qt, QTimer, QUrl, pyqtSignal
from PyQt6.QtGui import QPageLayout, QPageSize
from PyQt6.QtWebEngineCore import QWebEngineSettings
from PyQt6.QtWebEngineWidgets import QWebEngineView

try:
    import pymupdf as fitz  # type: ignore
except ImportError:  # pragma: no cover
    import fitz  # type: ignore


def weasyprint_available() -> bool:
    try:
        import weasyprint  # noqa: F401
        return True
    except Exception:  # OSError when the GTK DLLs are missing
        return False


def export_with_weasyprint(html_path: Path, pdf_path: Path) -> None:
    import weasyprint
    weasyprint.HTML(filename=str(html_path)).write_pdf(str(pdf_path))


@dataclass
class _Job:
    html: Path
    pdf: Path
    tag: Any


class PdfRenderer(QObject):
    """
    Queue-based Chromium printer. Owns one invisible QWebEngineView.

    Flow per job: load file -> wait until document.fonts reports "loaded"
    (webfonts load asynchronously, printing earlier gives fallback fonts)
    -> short settle delay -> printToPdf -> emit ``finished``.
    """

    finished = pyqtSignal(str, bool, object)  # pdf path, success, tag

    def __init__(self, parent: QObject | None = None):
        super().__init__(parent)
        self.view = QWebEngineView()
        # Rendered but never shown on screen. A page without a view can
        # print blank on some GPU drivers, so a hidden view is the safe route.
        self.view.setAttribute(Qt.WidgetAttribute.WA_DontShowOnScreen, True)
        # Otherwise this invisible window keeps the app alive after the user
        # closes the main window.
        self.view.setAttribute(Qt.WidgetAttribute.WA_QuitOnClose, False)
        self.view.resize(1240, 1754)
        self.view.show()
        s = self.view.settings()
        s.setAttribute(QWebEngineSettings.WebAttribute.PrintElementBackgrounds, True)
        s.setAttribute(QWebEngineSettings.WebAttribute.LocalContentCanAccessFileUrls, True)
        self.page = self.view.page()
        self.page.pdfPrintingFinished.connect(self._on_printed)
        self.view.loadFinished.connect(self._on_loaded)
        self._queue: deque[_Job] = deque()
        self._job: _Job | None = None

    # public -------------------------------------------------------------
    def render(self, html: Path, pdf: Path, tag: Any = None) -> None:
        self._queue.append(_Job(Path(html), Path(pdf), tag))
        self._next()

    # internals ----------------------------------------------------------
    def _next(self) -> None:
        if self._job is not None or not self._queue:
            return
        self._job = self._queue.popleft()
        self.view.load(QUrl.fromLocalFile(str(self._job.html)))

    def _on_loaded(self, ok: bool) -> None:
        if self._job is None:
            return
        if not ok:
            self._done(False)
            return
        self._wait_for_fonts(0)

    def _wait_for_fonts(self, attempt: int) -> None:
        def check(status: Any) -> None:
            if status == "loaded" or attempt > 60:  # give up after ~3 s
                QTimer.singleShot(150, self._print)
            else:
                QTimer.singleShot(50, lambda: self._wait_for_fonts(attempt + 1))
        self.page.runJavaScript("document.fonts.status", check)

    def _print(self) -> None:
        if self._job is None:
            return
        layout = QPageLayout(QPageSize(QPageSize.PageSizeId.A4),
                             QPageLayout.Orientation.Portrait, QMarginsF(0, 0, 0, 0))
        self._job.pdf.parent.mkdir(parents=True, exist_ok=True)
        self.page.printToPdf(str(self._job.pdf), layout)

    def _on_printed(self, path: str, ok: bool) -> None:
        self._done(ok)

    def _done(self, ok: bool) -> None:
        job, self._job = self._job, None
        if job:
            self.finished.emit(str(job.pdf), ok, job.tag)
        self._next()


def pdf_page_count(pdf: Path) -> int:
    with fitz.open(str(pdf)) as doc:
        return len(doc)


def pdf_first_page_png(pdf: Path, png: Path, width_px: int = 420) -> Path:
    """Rasterise page 1, used for the template gallery thumbnails."""
    with fitz.open(str(pdf)) as doc:
        page = doc[0]
        zoom = width_px / page.rect.width
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
        pix.save(str(png))
    return png
