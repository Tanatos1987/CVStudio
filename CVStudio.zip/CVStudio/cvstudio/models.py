"""
Data model.

A CV profile is stored as one JSON document (plus photo blobs) instead of a
dozen normalised tables. CV sections change shape often (a new optional
field, a new section) and a JSON column absorbs that without migrations.

The ``SECTIONS`` spec is the single source of truth for list sections. The
UI builds its entry cards from it, the translator reads the ``translate``
flags from it, and the templates rely on the keys.
"""
from __future__ import annotations

import copy
from dataclasses import dataclass, field
from typing import Any

# --------------------------------------------------------------------------
# Field specs
# --------------------------------------------------------------------------
# kind:      "line" (single line), "text" (multi-line, bullets allowed),
#            "level" (0-5 slider)
# translate: "text"  -> machine translation
#            "name"  -> Cyrillic -> Latin transliteration (BG -> EN only)
#            "date"  -> month names / "present" dictionary swap
#            None    -> never touched (emails, URLs, years)


@dataclass(frozen=True)
class FieldSpec:
    key: str
    label_en: str
    label_bg: str
    kind: str = "line"
    translate: str | None = "text"
    placeholder: str = ""
    wide: bool = False  # span both columns in the entry card grid


@dataclass(frozen=True)
class SectionSpec:
    key: str
    title_en: str
    title_bg: str
    fields: tuple[FieldSpec, ...]
    item_title_keys: tuple[str, ...]  # what the collapsed card shows


SECTIONS: tuple[SectionSpec, ...] = (
    SectionSpec(
        "experience", "Experience", "Опит",
        (
            FieldSpec("title", "Job title", "Длъжност", placeholder="Financial Controller"),
            FieldSpec("company", "Company", "Компания", translate="name", placeholder="Aqua Hotel Varna"),
            FieldSpec("start", "Start", "Начало", translate="date", placeholder="03/2019"),
            FieldSpec("end", "End", "Край", translate="date", placeholder="Present"),
            FieldSpec("location", "Location", "Локация", placeholder="Varna, Bulgaria"),
            FieldSpec("description", "Achievements (one per line, start with •)",
                      "Постижения (по едно на ред, започвайте с •)", kind="text", wide=True,
                      placeholder="• Cut breakfast food cost from 31% to 26% in one season\n"
                                  "• Rebuilt the supplier price list for 140 SKUs"),
        ),
        ("title", "company"),
    ),
    SectionSpec(
        "education", "Education", "Образование",
        (
            FieldSpec("degree", "Degree", "Степен", placeholder="MSc Accounting and Control"),
            FieldSpec("institution", "Institution", "Институция", placeholder="University of Economics - Varna"),
            FieldSpec("start", "Start", "Начало", translate="date", placeholder="2006"),
            FieldSpec("end", "End", "Край", translate="date", placeholder="2011"),
            FieldSpec("location", "Location", "Локация"),
            FieldSpec("description", "Notes", "Бележки", kind="text", wide=True),
        ),
        ("degree", "institution"),
    ),
    SectionSpec(
        "skills", "Skills", "Умения",
        (
            FieldSpec("name", "Skill", "Умение", placeholder="Python / pandas"),
            FieldSpec("level", "Level", "Ниво", kind="level", translate=None),
        ),
        ("name",),
    ),
    SectionSpec(
        "languages", "Languages", "Езици",
        (
            FieldSpec("name", "Language", "Език", placeholder="English"),
            FieldSpec("level", "Level", "Ниво", placeholder="C1 - fluent"),
        ),
        ("name", "level"),
    ),
    SectionSpec(
        "certifications", "Certifications", "Сертификати",
        (
            FieldSpec("name", "Certificate", "Сертификат", placeholder="ACCA Diploma in IFRS"),
            FieldSpec("issuer", "Issuer", "Издател"),
            FieldSpec("year", "Year", "Година", translate=None),
        ),
        ("name", "issuer"),
    ),
)

SECTION_BY_KEY = {s.key: s for s in SECTIONS}

PERSONAL_FIELDS: tuple[FieldSpec, ...] = (
    FieldSpec("full_name", "Full name", "Име и фамилия", translate="name"),
    FieldSpec("headline", "Headline", "Професионално заглавие", placeholder="Financial Controller, Hospitality"),
    FieldSpec("email", "Email", "Имейл", translate=None),
    FieldSpec("phone", "Phone", "Телефон", translate=None),
    FieldSpec("location", "Location", "Локация"),
    FieldSpec("website", "Website", "Уебсайт", translate=None),
    FieldSpec("linkedin", "LinkedIn", "LinkedIn", translate=None),
    FieldSpec("github", "GitHub", "GitHub", translate=None),
    FieldSpec("summary", "Profile summary", "Профил", kind="text"),
)

LETTER_FIELDS: tuple[FieldSpec, ...] = (
    FieldSpec("recipient", "Recipient", "Получател", placeholder="Hiring Manager"),
    FieldSpec("company", "Company", "Компания", translate="name"),
    FieldSpec("role", "Role you apply for", "Позиция"),
    FieldSpec("date", "Date", "Дата", translate="date"),
    FieldSpec("body", "Letter body", "Текст на писмото", kind="text"),
)


def empty_data() -> dict[str, Any]:
    return {
        "personal": {f.key: "" for f in PERSONAL_FIELDS},
        **{s.key: [] for s in SECTIONS},
        "cover_letter": {f.key: "" for f in LETTER_FIELDS},
    }


def normalise(data: dict[str, Any] | None) -> dict[str, Any]:
    """Fill in keys added in newer versions so old profiles never crash."""
    base = empty_data()
    if not data:
        return base
    for k, v in base.items():
        if k not in data:
            data[k] = copy.deepcopy(v)
        elif isinstance(v, dict):
            for sub in v:
                data[k].setdefault(sub, "")
    return data


@dataclass
class Profile:
    id: int | None
    name: str
    template: str = "modern_tech"
    accent: str = ""          # empty -> template default
    language: str = "en"      # language of the section labels ("en" / "bg")
    data: dict[str, Any] = field(default_factory=empty_data)
    photo: bytes | None = None           # cropped square JPEG
    photo_original: bytes | None = None  # kept so the user can re-crop
    updated_at: str = ""


# --------------------------------------------------------------------------
# Sample data, used for the template gallery thumbnails
# --------------------------------------------------------------------------
def sample_data(lang: str = "en") -> dict[str, Any]:
    """Fictional CV for the gallery thumbnails, in English or Bulgarian."""
    return _sample_bg() if lang == "bg" else _sample_en()


def _sample_bg() -> dict[str, Any]:
    d = _sample_en()
    d["personal"].update(
        full_name="Мира Костадинова",
        headline="Мениджър приходи и ценообразуване",
        location="Варна, България",
        summary=(
            "Управлявам приходите на курортен хотел с 212 стаи. Определям дневните цени "
            "за четири канала за резервации, преработих прогнозния модел на Python и "
            "увеличих RevPAR с 11,4% за летния сезон на 2025 г. без нито една кампания с отстъпки."
        ),
    )
    d["experience"] = [
        dict(title="Мениджър приходи и ценообразуване", company="Аква Ризорт Златни пясъци",
             start="04/2021", end="Настояще", location="Варна",
             description="• Преминах от седмично към дневно ценообразуване с модел в pandas\n"
                         "• Увеличих директните резервации от 18% на 29%, като спрях ценовите разлики в OTA\n"
                         "• Създадох калкулатор за групови оферти, който отделът продажби ползва за всяко запитване"),
        dict(title="Старши анализатор приходи", company="Черноморски хотели",
             start="09/2017", end="03/2021", location="Бургас",
             description="• Отговарях за 18-месечната прогноза на 5 хотела с общо 1040 стаи\n"
                         "• Замених 14 ръчни справки в Excel с едно табло в Power BI"),
        dict(title="Нощен одитор", company="Хотел Одесос",
             start="06/2015", end="08/2017", location="Варна",
             description="• Приключвах деня за хотел със 160 стаи и равнявах POS с PMS"),
    ]
    d["education"] = [dict(degree="Магистър, Икономика на туризма", institution="Икономически университет - Варна",
                           start="2013", end="2015", location="Варна", description="")]
    d["skills"] = [
        dict(name="Прогнозиране на приходи", level=5), dict(name="Python / pandas", level=4),
        dict(name="IDeaS G3 RMS", level=4), dict(name="Power BI", level=4),
        dict(name="Opera PMS", level=3), dict(name="Преговори по договори", level=3),
    ]
    d["languages"] = [dict(name="Български", level="Роден"), dict(name="Английски", level="C1"),
                      dict(name="Немски", level="B2")]
    d["certifications"] = [dict(name="Certified Revenue Management Executive", issuer="HSMAI", year="2022")]
    return d


def _sample_en() -> dict[str, Any]:
    d = empty_data()
    d["personal"].update(
        full_name="Mira Kostadinova",
        headline="Revenue & Pricing Manager",
        email="mira.kostadinova@mail.bg",
        phone="+359 88 412 7730",
        location="Varna, Bulgaria",
        website="mirak.bg",
        linkedin="linkedin.com/in/mirakostadinova",
        summary=(
            "Revenue manager for a 212-room seaside resort. I set daily rates for "
            "four booking channels, rebuilt the forecast model in Python and lifted "
            "RevPAR by 11.4% across the 2025 summer season without adding a single "
            "discount campaign."
        ),
    )
    d["experience"] = [
        dict(title="Revenue & Pricing Manager", company="Aqua Resort Golden Sands",
             start="04/2021", end="Present", location="Varna",
             description="• Moved rate decisions from weekly to daily using a pickup model in pandas\n"
                         "• Raised direct-booking share from 18% to 29% by fixing parity leaks on OTAs\n"
                         "• Built a group-quote calculator the sales team now uses for every RFP"),
        dict(title="Senior Revenue Analyst", company="Black Sea Hotels Group",
             start="09/2017", end="03/2021", location="Burgas",
             description="• Owned the 18-month forecast for 5 properties, 1,040 rooms in total\n"
                         "• Replaced 14 manual Excel reports with one Power BI dashboard"),
        dict(title="Night Auditor", company="Hotel Odessos",
             start="06/2015", end="08/2017", location="Varna",
             description="• Closed the day for a 160-room property and reconciled POS to PMS"),
    ]
    d["education"] = [
        dict(degree="MSc Tourism Economics", institution="University of Economics - Varna",
             start="2013", end="2015", location="Varna", description=""),
    ]
    d["skills"] = [
        dict(name="Revenue forecasting", level=5), dict(name="Python / pandas", level=4),
        dict(name="IDeaS G3 RMS", level=4), dict(name="Power BI", level=4),
        dict(name="Opera PMS", level=3), dict(name="Contract negotiation", level=3),
    ]
    d["languages"] = [
        dict(name="Bulgarian", level="Native"), dict(name="English", level="C1"),
        dict(name="German", level="B2"),
    ]
    d["certifications"] = [
        dict(name="Certified Revenue Management Executive", issuer="HSMAI", year="2022"),
    ]
    d["cover_letter"].update(
        recipient="Ms. Petrova", company="Sunrise Hotels", role="Director of Revenue",
        date="12 March 2026",
        body="I am writing to apply for the Director of Revenue role at Sunrise Hotels.\n\n"
             "Over the last four seasons I moved a 212-room resort from weekly to daily pricing "
             "and lifted RevPAR by 11.4%.\n\nI would welcome the chance to talk.",
    )
    return d
