"""
HTML rendering.

Every design lives in ``templates/<id>/`` and contains:

    meta.json    name, tagline, default accent
    style.css    the design (a Jinja template itself, so it can read colours)
    header.html  the header block, shared by the CV and the cover letter so
                 both documents carry the same identity
    cv.html      the CV
    letter.html  the matching cover letter

``templates/_shared/base.css`` holds what all designs need: embedded fonts,
A4 page setup, print colour handling and the on-screen "paper" frame used
by the live preview.

The renderer writes the HTML to a real file instead of handing a string to
the browser. A file URL lets the page reference local fonts, and there is no
size limit (QWebEngine's setHtml() caps at 2 MB, which a photo can hit).
"""
from __future__ import annotations

import base64
import colorsys
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from jinja2 import Environment, FileSystemLoader, select_autoescape
from markupsafe import Markup, escape

from .models import Profile
from .paths import as_file_url, cache_dir, fonts_dir, templates_dir
from .translator import BULLET_RE

LABELS: dict[str, dict[str, str]] = {
    "en": {
        "profile": "Profile", "experience": "Experience", "education": "Education",
        "skills": "Skills", "languages": "Languages", "certifications": "Certifications",
        "contact": "Contact", "email": "Email", "phone": "Phone", "location": "Location",
        "website": "Website", "linkedin": "LinkedIn", "github": "GitHub",
        "dear": "Dear", "default_recipient": "Hiring Manager", "regards": "Kind regards,",
        "re": "Application for", "letter": "Cover letter",
    },
    "bg": {
        "profile": "Профил", "experience": "Професионален опит", "education": "Образование",
        "skills": "Умения", "languages": "Езици", "certifications": "Сертификати",
        "contact": "Контакти", "email": "Имейл", "phone": "Телефон", "location": "Локация",
        "website": "Уебсайт", "linkedin": "LinkedIn", "github": "GitHub",
        "dear": "Уважаеми/а", "default_recipient": "г-н/г-жо", "regards": "С уважение,",
        "re": "Кандидатура за позиция", "letter": "Мотивационно писмо",
    },
}


# --------------------------------------------------------------------------
# Template registry
# --------------------------------------------------------------------------
@dataclass(frozen=True)
class TemplateInfo:
    id: str
    name: str
    tagline: str
    default_accent: str
    swatches: tuple[str, ...]
    name_bg: str = ""
    tagline_bg: str = ""


def list_templates() -> list[TemplateInfo]:
    items: list[TemplateInfo] = []
    for folder in sorted(templates_dir().iterdir()):
        meta_file = folder / "meta.json"
        if folder.name.startswith("_") or not meta_file.exists():
            continue
        meta = json.loads(meta_file.read_text(encoding="utf-8"))
        items.append(TemplateInfo(
            id=folder.name, name=meta["name"], tagline=meta["tagline"],
            default_accent=meta["default_accent"], swatches=tuple(meta.get("swatches", [])),
            name_bg=meta.get("name_bg", ""), tagline_bg=meta.get("tagline_bg", ""),
        ))
    items.sort(key=lambda t: json.loads((templates_dir() / t.id / "meta.json")
                                        .read_text(encoding="utf-8")).get("order", 99))
    return items


def template_info(template_id: str) -> TemplateInfo:
    for t in list_templates():
        if t.id == template_id:
            return t
    return list_templates()[0]


# --------------------------------------------------------------------------
# Colour helpers: every design derives its palette from ONE accent colour
# --------------------------------------------------------------------------
def _hex_to_rgb(h: str) -> tuple[float, float, float]:
    h = h.lstrip("#")
    if len(h) == 3:
        h = "".join(c * 2 for c in h)
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))  # type: ignore[return-value]


def _rgb_to_hex(r: float, g: float, b: float) -> str:
    return "#{:02x}{:02x}{:02x}".format(*(max(0, min(255, round(c * 255))) for c in (r, g, b)))


def _mix(a: str, b: str, t: float) -> str:
    ra, ga, ba = _hex_to_rgb(a)
    rb, gb, bb = _hex_to_rgb(b)
    return _rgb_to_hex(ra + (rb - ra) * t, ga + (gb - ga) * t, ba + (bb - ba) * t)


def _luminance(h: str) -> float:
    def lin(c: float) -> float:
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    r, g, b = (lin(c) for c in _hex_to_rgb(h))
    return 0.2126 * r + 0.7152 * g + 0.0722 * b


def palette(accent: str) -> dict[str, str]:
    """accent -> a small family of tones the CSS can use as variables."""
    r, g, b = _hex_to_rgb(accent)
    hue, light, sat = colorsys.rgb_to_hls(r, g, b)
    deep = _rgb_to_hex(*colorsys.hls_to_rgb(hue, max(0.12, light * 0.42), min(1, sat * 0.9)))
    return {
        "accent": accent,
        "accent_deep": deep,                       # dark tone of the same hue
        "accent_soft": _mix(accent, "#ffffff", 0.84),
        "accent_mist": _mix(accent, "#ffffff", 0.93),
        "accent_ink": "#ffffff" if _luminance(accent) < 0.42 else "#141414",
    }


# --------------------------------------------------------------------------
# Jinja filters
# --------------------------------------------------------------------------
def rich_text(text: str | None) -> Markup:
    """
    Plain text with bullets -> HTML. Consecutive bullet lines become one
    <ul>, other non-empty lines become <p>. Everything is escaped.
    """
    if not text:
        return Markup("")
    html: list[str] = []
    in_list = False
    for line in text.split("\n"):
        m = BULLET_RE.match(line)
        if m and m.group(2).strip():
            if not in_list:
                html.append("<ul>")
                in_list = True
            html.append(f"<li>{escape(m.group(2).strip())}</li>")
            continue
        if in_list:
            html.append("</ul>")
            in_list = False
        if line.strip():
            html.append(f"<p>{escape(line.strip())}</p>")
    if in_list:
        html.append("</ul>")
    return Markup("".join(html))


def initials(name: str | None) -> str:
    parts = [p for p in (name or "").split() if p]
    return "".join(p[0] for p in parts[:2]).upper() or "CV"


def split_name(name: str | None) -> tuple[str, str]:
    parts = (name or "").split()
    if len(parts) < 2:
        return (name or "", "")
    return (" ".join(parts[:-1]), parts[-1])


def pretty_url(url: str | None) -> str:
    u = (url or "").strip()
    for prefix in ("https://", "http://", "www."):
        if u.lower().startswith(prefix):
            u = u[len(prefix):]
    return u.rstrip("/")


def contacts(p: dict[str, Any]) -> list[dict[str, str]]:
    """Ordered contact rows with the icon name the templates should draw."""
    rows = []
    for key in ("email", "phone", "location", "website", "linkedin", "github"):
        value = (p.get(key) or "").strip()
        if value:
            text = pretty_url(value) if key in ("website", "linkedin", "github") else value
            rows.append({"key": key, "text": text})
    return rows


def date_range(item: dict[str, Any]) -> str:
    start, end = (item.get("start") or "").strip(), (item.get("end") or "").strip()
    if start and end:
        return f"{start} - {end}"
    return start or end


# --------------------------------------------------------------------------
# Engine
# --------------------------------------------------------------------------
class TemplateEngine:
    def __init__(self) -> None:
        self.env = Environment(
            loader=FileSystemLoader(str(templates_dir())),
            autoescape=select_autoescape(["html"]),
            trim_blocks=True,
            lstrip_blocks=True,
        )
        self.env.filters.update(rich=rich_text, initials=initials, pretty_url=pretty_url)
        self.env.globals.update(split_name=split_name, date_range=date_range, contacts=contacts)

    def context(self, profile: Profile, data: dict[str, Any] | None = None) -> dict[str, Any]:
        info = template_info(profile.template)
        accent = profile.accent or info.default_accent
        photo_uri = ""
        if profile.photo:
            photo_uri = "data:image/jpeg;base64," + base64.b64encode(profile.photo).decode()
        d = data or profile.data
        lang = profile.language if profile.language in LABELS else "en"
        return {
            "d": d,
            "p": d["personal"],
            "letter": d["cover_letter"],
            "L": LABELS[lang],
            "lang": lang,
            "photo": photo_uri,
            "fonts_url": as_file_url(fonts_dir()),
            "tpl": info,
            **palette(accent),
        }

    def render(self, profile: Profile, kind: str = "cv", data: dict[str, Any] | None = None) -> str:
        template = self.env.get_template(f"{profile.template}/{kind}.html")
        return template.render(**self.context(profile, data), kind=kind)

    def render_to_file(self, profile: Profile, kind: str = "cv", name: str | None = None,
                       data: dict[str, Any] | None = None) -> Path:
        html = self.render(profile, kind, data)
        out = cache_dir("render") / (name or f"{kind}_{profile.id or 'new'}.html")
        out.write_text(html, encoding="utf-8")
        return out
