"""
Cover letter draft generator.

Works offline and deterministically: it reads the profile and writes a
first draft the user then edits. It does not invent achievements. Every
concrete claim in the draft comes from a bullet the user already wrote.

The visual match with the CV is handled by the templates (letter.html
reuses header.html and style.css of the same design), so this module only
produces text.
"""
from __future__ import annotations

import re
from datetime import date
from typing import Any

from .translator import BULLET_RE

_MONTHS_EN = ["January", "February", "March", "April", "May", "June", "July",
              "August", "September", "October", "November", "December"]
_MONTHS_BG = ["януари", "февруари", "март", "април", "май", "юни", "юли",
              "август", "септември", "октомври", "ноември", "декември"]


def today_string(lang: str) -> str:
    t = date.today()
    months = _MONTHS_BG if lang == "bg" else _MONTHS_EN
    suffix = " г." if lang == "bg" else ""
    return f"{t.day} {months[t.month - 1]} {t.year}{suffix}"


def _years_of_experience(experience: list[dict[str, Any]]) -> int | None:
    years = []
    for item in experience:
        m = re.search(r"(19|20)\d{2}", item.get("start") or "")
        if m:
            years.append(int(m.group(0)))
    if not years:
        return None
    return max(1, date.today().year - min(years))


def _best_bullets(experience: list[dict[str, Any]], limit: int = 2) -> list[str]:
    """Prefer bullets containing numbers: they read as evidence."""
    bullets: list[str] = []
    for item in experience[:2]:
        for line in (item.get("description") or "").split("\n"):
            m = BULLET_RE.match(line)
            text = (m.group(2) if m else line).strip().rstrip(".")
            if len(text) > 12:
                bullets.append(text)
    bullets.sort(key=lambda b: (not re.search(r"\d", b), len(b)))
    return bullets[:limit]


def _lower_first(s: str) -> str:
    return s[:1].lower() + s[1:] if s and not s[:2].isupper() else s


def generate(data: dict[str, Any], lang: str = "en") -> str:
    p = data["personal"]
    letter = data["cover_letter"]
    exp = data.get("experience", [])
    skills = [s["name"] for s in sorted(data.get("skills", []),
                                        key=lambda s: -int(s.get("level") or 0)) if s.get("name")]
    role = letter.get("role") or ("позицията" if lang == "bg" else "the position")
    company = letter.get("company") or ("Вашата компания" if lang == "bg" else "your company")
    years = _years_of_experience(exp)
    current = exp[0] if exp else {}
    evidence = _best_bullets(exp)

    if lang == "bg":
        paras = [f"Пиша Ви във връзка с позицията {role} в {company}."]
        if current.get("title"):
            s = f"В момента съм {current['title']}"
            if current.get("company"):
                s += f" в {current['company']}"
            if years:
                s += f", с {years} години опит в сферата"
            paras.append(s + ".")
        if evidence:
            paras.append("Няколко резултата, с които се гордея:\n" +
                         "\n".join(f"• {e}" for e in evidence))
        if skills:
            paras.append("Най-силните ми умения са " + ", ".join(skills[:4]) +
                         f". Те съвпадат точно с това, от което {company} има нужда за тази роля.")
        paras.append("Ще се радвам на разговор, в който да покажа как мога да помогна на екипа Ви. "
                     "Благодаря Ви за отделеното време.")
    else:
        paras = [f"I am writing to apply for the {role} role at {company}."]
        if current.get("title"):
            s = f"I currently work as {current['title']}"
            if current.get("company"):
                s += f" at {current['company']}"
            if years:
                s += f", with {years} years in the field"
            paras.append(s + ".")
        if evidence:
            paras.append("Two results I am proud of:\n" + "\n".join(f"• {e}" for e in evidence))
        if skills:
            paras.append("My strongest skills are " + ", ".join(skills[:4]) +
                         f", and I would bring them to {company} from the first week.")
        paras.append("I would welcome a conversation about how I can help your team. "
                     "Thank you for your time.")

    if p.get("summary") and len(paras) < 4:
        paras.insert(1, _lower_first(p["summary"]).capitalize())
    return "\n\n".join(paras)
